(function registerInkDOSServiceWorker(){
'use strict';
if(!navigator.serviceWorker||!/^https?:$/.test(location.protocol))return;
const script=document.currentScript;
if(!script||!script.src)return;
const scriptUrl=new URL(script.src);
const serviceWorkerUrl=new URL('../service-worker.js',scriptUrl);
if(scriptUrl.search)serviceWorkerUrl.search=scriptUrl.search;
const scopeUrl=new URL('../',scriptUrl);
const reloadKey='inkdos-sw-controller-reload:'+serviceWorkerUrl.href;
let reloading=false;
navigator.serviceWorker.addEventListener('controllerchange',()=>{
  if(reloading)return;
  try{
    if(sessionStorage.getItem(reloadKey)==='1')return;
    sessionStorage.setItem(reloadKey,'1');
  }catch(error){
    console.warn('InkDOS could not persist the Service Worker reload marker.',error);
  }
  reloading=true;
  location.reload();
});
navigator.serviceWorker.register(serviceWorkerUrl.href,{
  scope:scopeUrl.pathname,
  updateViaCache:'none'
}).then(registration=>registration.update()).catch(error=>{
  console.warn('InkDOS offline support could not be registered.',error);
});
})();
