InkDOS 2.0.0 CLEAN FULL SNAPSHOT UPDATE
All five frozen app source trees are physically included under files/apps/.
No 1.x runtime is copied into the candidate. .github/workflows is preserved only because update packages are forbidden from modifying the installed update bootloader.
PDF runtime is not installed in this release.
