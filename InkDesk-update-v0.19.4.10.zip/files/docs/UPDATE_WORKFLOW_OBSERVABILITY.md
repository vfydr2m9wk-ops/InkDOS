# Update workflow observability

Development sequence `0.19.4.10` improves the incremental update workflow after
a rolled-back attempt exposed an obsolete test assertion.

The failed attempt did not consume sequence 10. Its real failure was
`test_index_loads_helper_before_application`, which required the literal
`app.js?v=0.19.4.6` after a package advanced the PDF script version. The
transaction restored the repository.

Future workflow runs capture the complete updater output, record the updater
exit code, and add a failure summary containing:

- package label and sequence;
- explicit rollback confirmation;
- the last transaction log lines;
- automatic recognition of stale exact asset-version assertions;
- clarification that the missing `generate_release_metadata.py` line may come
  from the intentional rollback test rather than the final failure.

The permanent updater now writes a JSON failure report when possible.
