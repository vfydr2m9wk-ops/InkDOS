# PDF unified Save

Development sequence `0.19.4.10` replaces parallel PDF export actions with one
Save command in the title bar.

## Visible actions

The PDF workspace now exposes:

- Open PDF.
- Save annotated PDF.
- Open in system PDF viewer.
- Fullscreen.

The following visible actions are removed:

- Export review JSON.
- Import review JSON.
- Save PDF copy as a separate command.
- Save original PDF.
- Print.

Bookmarks remain a review-navigation feature rather than an export command.

## Why PDF.js saveDocument was insufficient

InkDesk review marks are stored in a local sidecar and drawn in an HTML review
layer. PDF.js `saveDocument()` can preserve supported internal PDF state such as
some form changes, but it does not automatically incorporate InkDesk's custom
HTML review rectangles.

The normal Save path therefore renders each PDF page locally with PDF.js, draws
the InkDesk review layer on that page, encodes the page, and builds one new PDF
copy.

## Included review marks

The saved copy includes:

- selected-text highlights;
- selected-text underlines;
- selected-text comments with a visible callout;
- free marker regions;
- inserted free text;
- supported PDF content visible in the PDF.js page render.

The original PDF is never overwritten. The downloaded file is named:

```text
original-name-modified.pdf
```

## Local and offline behavior

Rendering and PDF construction happen entirely in the browser. Pages are
processed one at a time to avoid retaining a canvas for every page in memory.
The service worker caches the exporter for offline use.

The editable InkDesk review sidecar remains in local storage after Save.

## Export trade-off

The exported review is flattened into rendered page images. This guarantees
that InkDesk marks are visible in ordinary PDF viewers, but text in the exported
copy is not selectable and form fields are no longer editable. The original PDF
remains unchanged and retains its original text and form structure.

The default export uses approximately 144 DPI with a per-page pixel limit.
