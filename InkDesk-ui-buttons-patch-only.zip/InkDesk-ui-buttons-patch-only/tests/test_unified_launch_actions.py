from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path):
    return (ROOT / path).read_text(encoding="utf-8")


def test_launch_buttons_use_unified_visible_labels_and_roles():
    docs = read("apps/documents/index.html")
    sheets = read("apps/spreadsheets/index.html")
    slides = read("apps/presentations/index.html")
    pdf = read("apps/pdf/index.html")
    txt = read("apps/txt/index.html")
    epub = read("apps/epub/index.html")

    assert 'class="open-primary new-primary"' in docs
    assert 'class="open-primary open-document-primary"' in docs
    for page in (sheets, slides, txt):
        assert 'class="start-btn secondary"' in page
        assert 'class="start-btn primary"' in page
        assert ">New document<" in page
        assert ">Open document<" in page
    for page in (pdf, epub):
        assert ">Open document<" in page


def test_unified_launch_action_css_uses_existing_per_app_accent():
    css = read("shared/ui/visual-foundation-v0203.css")
    for color in ("#2f6fed", "#267a45", "#d64a24", "#b42318", "#d9a514", "#7655c7"):
        assert color in css
    assert "Unified launch actions patch" in css
    assert "background:var(--ink-accent)!important" in css
    assert "background:var(--ink-surface,#fff)!important" in css
    assert "grid-template-columns:repeat(2,minmax(0,1fr))!important" in css


def test_service_worker_cache_bumped_for_ui_patch():
    sw = read("service-worker.js")
    assert "inkdesk-shell-v1.0.0-beta.1-ui55" in sw
