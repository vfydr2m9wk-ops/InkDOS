InkDesk — Unified launch buttons patch (2026-08-09)

Goal
- New document: white/light button, dark text, + icon.
- Open document: app's existing accent color, white text, folder icon.
- Same typography, dimensions, spacing and icon geometry in all apps.
- Existing accent colors are preserved:
  Documents blue; Spreadsheets green; Presentations orange; PDF red; TXT yellow; EPUB purple.
- PDF and EPUB keep one Open document action.
- Two-action workspaces keep New on the left and Open on the right on wider screens; stack responsively on phones.
- Service worker cache key is bumped so GitHub Pages clients receive the new UI.

Apply
Copy the files in this package over the same paths in your InkDesk repository, then commit/push them.

Validation
- 30 focused UI/regression tests passed.
- CHECKSUMS.sha256 verification passed (404 files).
