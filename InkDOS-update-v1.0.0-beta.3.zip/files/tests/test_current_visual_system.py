from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
CURRENT = ROOT / 'shared' / 'ui' / 'current.css'


class CurrentVisualSystemTests(unittest.TestCase):
    def test_single_current_layer_replaces_patch_stack(self):
        self.assertTrue(CURRENT.is_file())
        shell = (ROOT / 'shared' / 'office-shell.js').read_text(encoding='utf-8')
        self.assertEqual(shell.count("'current.css'"), 1)
        for name in (
            'visual-foundation-' + 'v0203.css', 'content-workspaces-' + 'v02031.css',
            'workspace-unification-' + 'v02031.css', 'spreadsheets-' + 'beta1-polish.css',
            'light-' + 'only.css',
        ):
            self.assertFalse((ROOT / 'shared' / 'ui' / name).exists(), name)
            self.assertNotIn(name, shell)

    def test_bundle_keeps_cross_workspace_visual_contracts(self):
        css = CURRENT.read_text(encoding='utf-8')
        for marker in (
            'body.office-documents', 'body.office-spreadsheets',
            'body.office-presentations', 'body.office-pdf',
            'body.office-txt', 'body.office-epub',
            '#nameBox', '#sheetTabs > #addSheetBtn',
            'color-scheme: light !important',
        ):
            self.assertIn(marker, css)

    def test_inactive_future_theme_is_not_in_active_tree(self):
        self.assertFalse((ROOT / 'shared' / 'future').exists())
        worker = (ROOT / 'service-worker.js').read_text(encoding='utf-8')
        self.assertNotIn('shared/future', worker)


if __name__ == '__main__':
    unittest.main()
