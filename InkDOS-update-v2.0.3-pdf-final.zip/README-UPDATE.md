# InkDOS 2.0.3 — PDF FINAL update

For InkDOS 2.0.2, applied sequence 70. Applies sequence 71 with full validation.

1. Upload this ZIP unchanged to the root of vfydr2m9wk-ops/InkDOS.
2. Open Actions → InkDOS integrity and update → Run workflow. Select main, enter this ZIP filename, leave validation_profile as package and dry_run as false to apply.

The installed workflow validates the candidate, preserves its own protected bytes, commits the update and requests the Pages rebuild. Uploading the ZIP alone does not apply it because update ZIP pushes are excluded from automatic workflow execution.

The package adds the PDF app, Home link and centered Open PDF card, updates offline caching and pins the six-app source lock. The other five app trees are unchanged. No PDF fixtures, sample documents, screenshots or internal inspection hook are installed. Release validation scripts remain present. The obsolete tests directory is replaced by equivalent release contract validation under scripts/.

After deployment, the Home version should read InkDOS 2.0.3 and its PDF card should be active. PDF's editing engine retains its P4.2 version. The app may be opened directly at apps/pdf/index.html without visiting Home. This is a modular multi-file app; file:// support depends on the host browser.

Full audit and architecture notes are installed under docs/. No repository changes were published by creating this ZIP.
