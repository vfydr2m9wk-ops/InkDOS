#!/usr/bin/env python3
"""Merge 0.19.1-beta hardening claims into the current README without replacing it."""
from __future__ import annotations

from pathlib import Path

README = Path("README.md")
text = README.read_text(encoding="utf-8")
original = text

replacements = {
    "Current version: 0.19.0-beta": "Current version: 0.19.1-beta",
    "**Project status: Beta (`0.19.0-beta`).**": "**Project status: Beta (`0.19.1-beta`).**",
    "InkDesk is a local-first, offline Office suite built with standard web technologies.":
        "InkDesk is a local-first browser productivity suite built with standard web technologies.",
    "A download request does not guarantee that the operating system completed the write successfully. Users should confirm that the exported file exists and can be reopened before closing important work.":
        "After requesting a download, InkDesk reports “Download requested — not verified” and keeps unsaved-change protection active. A copy is marked verified only after it is reopened and its SHA-256 fingerprint and size match the generated export. The browser still cannot prove that every operating-system write completed successfully.",
    "InkDesk is designed with compatibility fallbacks for:":
        "InkDesk is intended to remain usable, subject to release-specific validation, in:",
    "Native Firefox, Safari, physical iPadOS, and embedded-browser testing may require additional manual validation for each release.":
        "Playwright Chromium, Firefox, and WebKit are CI targets. These runs do not constitute native Safari, physical iPadOS, or embedded-host validation; unexecuted environments remain marked not tested.",
}
for before, after in replacements.items():
    text = text.replace(before, after)

heading = "0.19.1-beta reliability and security hardening"
section = f"""

{heading}

This update introduces a shared dirty/export lifecycle for Documents, Spreadsheets, and Presentations. Requesting a browser download no longer clears unsaved-change protection or displays a definitive saved state.

Imported Office files are treated as untrusted ZIP and XML input. The shared runtime validates normalized package paths, duplicate and colliding entries, header consistency, encryption, ZIP64, compression methods, resource limits, XML declarations and complexity. DOCX-derived editable content is rebuilt through a deny-by-default DOM allowlist. Spreadsheet arithmetic uses a deterministic limited parser instead of `eval` or `Function`.

Unsupported Office features and formulas remain subject to partial compatibility. Keep source files and backups, reopen exports, and validate critical documents in the application that will ultimately consume them.
"""
if heading not in text:
    anchors = [
        "Important documents should always be backed up before editing.",
        "Keep the original file, work from backup copies",
        "## Main principles",
        "Main principles",
    ]
    inserted = False
    for anchor in anchors:
        if anchor in text:
            position = text.index(anchor) + len(anchor)
            text = text[:position] + section + text[position:]
            inserted = True
            break
    if not inserted:
        text += section

validation = """

0.19.1-beta validation commands

```bash
python3 scripts/verify_checksums.py
python3 scripts/validate_repository.py
python3 scripts/audit_source.py
python3 -m unittest discover -s tests -p "test_*.py"
node tests/js/security-modules.test.js
PLAYWRIGHT_BROWSER=chromium python3 scripts/run_browser_regressions.py --group package-security
PLAYWRIGHT_BROWSER=chromium python3 scripts/run_browser_regressions.py --group lifecycle
PLAYWRIGHT_BROWSER=chromium python3 scripts/run_browser_regressions.py --group isolation-offline
PLAYWRIGHT_BROWSER=chromium python3 scripts/run_browser_regressions.py --group documents-presentations
PLAYWRIGHT_BROWSER=chromium python3 scripts/run_browser_regressions.py --group spreadsheets
```
"""
if "0.19.1-beta validation commands" not in text:
    marker = "A release should not be considered validated unless the complete regression suite passes repeatedly without intermittent failures."
    if marker in text:
        position = text.index(marker) + len(marker)
        text = text[:position] + validation + text[position:]
    else:
        text += validation

if text == original:
    raise SystemExit("README merge made no changes; current README shape is not recognized.")
README.write_text(text.rstrip() + "\n", encoding="utf-8")
print("README.md updated without replacing the current document wholesale.")
