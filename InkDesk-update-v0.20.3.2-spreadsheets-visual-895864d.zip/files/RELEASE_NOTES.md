# InkDesk v0.20.3.2 — Spreadsheets Visual Pass

This release continues the user-visible 0.20.3 UX train with a dedicated presentation pass for Spreadsheets while keeping the v0.20.2.31 structural/data-safety baseline frozen.

## What changes

- Adds `shared/ui/spreadsheets-v02032.css`, loaded after the shared visual foundation and the v0.20.3.1 content-workspace layer.
- Refines the Spreadsheet titlebar and makes an available Save-copy action visually clearer without changing save semantics.
- Rebalances the formatting toolbar into quieter controls with clearer selection and command grouping.
- Gives the formula row separate visual roles for cell address, `fx` context and the editable expression field.
- Improves column/row-header contrast, range/active-cell hierarchy and the fill-handle treatment without changing grid geometry or selection logic.
- Reworks sheet tabs, selection status and zoom controls into a calmer workbook footer.
- Adds compact/touch refinements that keep commands available through scrollable chrome rather than removing functionality.
- Adds a dedicated static contract and a 20th Chromium regression for Spreadsheet presentation geometry and states.

## Intentionally unchanged

Formula parsing/evaluation, formula draft lifecycle, Undo/Redo history, XLS/BIFF8 and XLSX engines, recovery/session isolation, transactional Open/New/Discard and export/download safety are unchanged apart from release identity/cache metadata.

Full notes: [`docs/releases/RELEASE_NOTES_0.20.3.2.md`](docs/releases/RELEASE_NOTES_0.20.3.2.md)

Historical notes: [`docs/releases/`](docs/releases/)
