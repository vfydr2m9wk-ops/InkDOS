#!/usr/bin/env python3
from __future__ import annotations

import json
import os
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[2]
RESULT = ROOT / "tests" / "browser" / "results" / "spreadsheets_visual_02032.json"


def read_css(*relatives: str) -> str:
    return "\n".join((ROOT / relative).read_text(encoding="utf-8") for relative in relatives)


CSS = read_css(
    "apps/spreadsheets/styles.css",
    "apps/spreadsheets/formula-reference.css",
    "apps/spreadsheets/formula-editor.css",
    "shared/office-shell.css",
    "shared/ui/design-tokens.css",
    "shared/ui/components.css",
    "shared/ui/workspace-layout.css",
    "shared/ui/visual-foundation.css",
    "shared/ui/visual-foundation-v0203.css",
    "shared/ui/content-workspaces-v02031.css",
    "shared/ui/spreadsheets-v02032.css",
)


def style(page, selector: str, prop: str) -> str:
    return page.locator(selector).evaluate(
        "(el, prop) => getComputedStyle(el).getPropertyValue(prop).trim()", prop
    )


def main() -> int:
    browser_name = os.environ.get("INKDESK_BROWSER", "chromium").strip().lower()
    with sync_playwright() as p:
        launcher = getattr(p, browser_name)
        kwargs = {}
        executable = (
            os.environ.get("CHROMIUM_PATH")
            or os.environ.get("INKDESK_BROWSER_EXECUTABLE", "")
        ).strip()
        if executable and browser_name == "chromium":
            kwargs["executable_path"] = executable
            kwargs["args"] = ["--no-sandbox"]
        browser = launcher.launch(headless=True, **kwargs)
        page = browser.new_page(viewport={"width": 1280, "height": 800})
        page.set_content(f"""<!doctype html><style>{CSS}</style>
        <body class='office-product office-spreadsheets'>
          <header class='titlebar'><div class='left'><button class='icon-btn'>H</button></div><div class='document-title'><span class='office-badge'>S</span><input class='title-input' value='Budget.xlsx'></div><div class='right'><button id='saveBtn' class='icon-btn save'>S</button></div></header>
          <section class='toolbar'><select><option>Calibri</option></select><select><option>11</option></select><span class='separator'></span><button id='boldBtn' class='active-format'>B</button><button id='italicBtn'>I</button><span class='separator'></span><button id='mergeBtn'>Merge</button><select id='operationSelect'><option>Operations</option></select><span class='view-switch'><button class='active'>Sheet</button><button>Page</button></span><button id='gridlinesBtn'>Gridlines</button><span class='viewer-label'>InkDesk</span></section>
          <section class='formula-row'><input id='nameBox' value='A1'><span class='fx'>fx</span><div class='formula-editor'><input id='formulaInput' value='=SUM(A1:A3)'></div></section>
          <main><div id='gridViewport'><div id='grid' style='--cols:2'><div class='corner'></div><div class='col-header header-selected'>A</div><div class='col-header'>B</div><div class='row-header header-selected'>1</div><div class='cell selected'>10<div class='fill-handle'></div></div><div class='cell in-range'>20</div></div></div></main>
          <footer><div id='sheetTabs'><button class='active'>Sheet1</button><button>Sheet2</button><button id='addSheetBtn'>+</button></div><div class='status'><span id='selectionStats'>Sum: 30</span><div class='zoom-controls'><button>−</button><input type='range'><button>+</button><span id='zoomLabel'>100%</span></div></div></footer>
        </body>""")

        result = {
            "titlebar_height": style(page, ".titlebar", "height"),
            "toolbar_height": style(page, ".toolbar", "height"),
            "formula_height": style(page, ".formula-row", "height"),
            "name_box_width": style(page, "#nameBox", "width"),
            "formula_radius": style(page, ".formula-editor", "border-radius"),
            "save_background": style(page, "#saveBtn", "background-color"),
            "active_format_background": style(page, "#boldBtn", "background-color"),
            "selected_outline": style(page, ".cell.selected", "outline-width"),
            "active_sheet_color": style(page, "#sheetTabs button.active", "color"),
            "footer_height": style(page, "footer", "height"),
            "zoom_border_left": style(page, ".zoom-controls", "border-left-width"),
        }
        page.set_viewport_size({"width": 390, "height": 780})
        result["mobile_badge_display"] = style(page, ".office-badge", "display")
        result["mobile_name_width"] = style(page, "#nameBox", "width")
        browser.close()

    RESULT.parent.mkdir(parents=True, exist_ok=True)
    RESULT.write_text(json.dumps(result, indent=2), encoding="utf-8")
    assert result["titlebar_height"] == "44px", result
    assert result["toolbar_height"] == "44px", result
    assert result["formula_height"] == "40px", result
    assert result["name_box_width"] == "74px", result
    assert result["formula_radius"] == "8px", result
    assert result["save_background"] != "rgba(0, 0, 0, 0)", result
    assert result["active_format_background"] != "rgba(0, 0, 0, 0)", result
    assert result["selected_outline"] == "2px", result
    assert result["footer_height"] == "34px", result
    assert result["zoom_border_left"] == "1px", result
    assert result["mobile_badge_display"] == "none", result
    assert result["mobile_name_width"] == "58px", result
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
