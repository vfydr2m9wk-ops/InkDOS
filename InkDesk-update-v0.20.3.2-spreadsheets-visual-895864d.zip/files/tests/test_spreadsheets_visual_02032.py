from __future__ import annotations

from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
CSS = ROOT / "shared" / "ui" / "spreadsheets-v02032.css"


class SpreadsheetsVisual02032Tests(unittest.TestCase):
    def test_visual_layer_exists_is_bounded_and_presentation_only(self):
        text = CSS.read_text(encoding="utf-8")
        lowered = text.lower()
        self.assertLessEqual(len(text.splitlines()), 500)
        self.assertIn("body.office-spreadsheets", text)
        for forbidden in (
            "indexeddb", "localstorage", "fetch(", "xmlhttprequest",
            "undostack", "redostack", "formulaengine", "documentkey",
            "sessionid", "xlsxengine", "xlsbiff",
        ):
            self.assertNotIn(forbidden, lowered)

    def test_layer_loads_after_shared_and_content_visual_layers(self):
        shell = (ROOT / "shared" / "office-shell.js").read_text(encoding="utf-8")
        foundation = shell.index("addStylesheet('visual-foundation-v0203.css')")
        content = shell.index("addStylesheet('content-workspaces-v02031.css')")
        spreadsheets = shell.index("addStylesheet('spreadsheets-v02032.css')")
        self.assertLess(foundation, content)
        self.assertLess(content, spreadsheets)

    def test_service_worker_precaches_spreadsheet_visual_layer(self):
        worker = (ROOT / "service-worker.js").read_text(encoding="utf-8")
        self.assertIn("./shared/ui/spreadsheets-v02032.css", worker)

    def test_visual_contract_covers_workbook_hierarchy(self):
        text = CSS.read_text(encoding="utf-8")
        for selector in (
            ".titlebar", ".toolbar", ".formula-row", "#nameBox",
            ".formula-editor", ".col-header", ".row-header", ".cell.selected",
            "#sheetTabs", ".status", ".zoom-controls", ".start-card",
        ):
            self.assertIn(selector, text)

    def test_no_existing_spreadsheet_commands_are_hidden_by_the_visual_layer(self):
        compact = CSS.read_text(encoding="utf-8").replace(" ", "").replace("\n", "")
        for control in (
            "#saveBtn", "#boldBtn", "#italicBtn", "#underlineBtn",
            "#mergeBtn", "#operationSelect", "#gridlinesBtn",
            "#formulaInput", "#sheetTabs", ".zoom-controls",
        ):
            self.assertNotIn(f"{control}{{display:none", compact)

    def test_compact_touch_and_reduced_motion_rules_exist(self):
        text = CSS.read_text(encoding="utf-8")
        self.assertIn("@media(max-width:900px)", text)
        self.assertIn("@media(max-width:620px)", text)
        self.assertIn("@media(pointer:coarse)", text)
        self.assertIn("@media(prefers-reduced-motion:reduce)", text)


if __name__ == "__main__":
    unittest.main()
