# InkDOS refinement worklog — checkpoint 2

## Baseline

- Source package: `1.0.0-beta.5`.
- Source sequence: `62`.
- Source state was confirmed `complete` before this checkpoint.

## Changes in checkpoint 2

- `shared/ui/refinement-home.css`: added a canonical theme bridge so Home, suite controls and shared shell consume the same background/surface/text/muted/border/hover/selected state; dark mode now maps inherited `--surface-soft`, `--muted` and `--edge` to the dark palette.
- `shared/ui/refinement-home.css`: added 20 px mobile inline gutter with safe-area support and retained an intentional horizontally scrollable Recent filter strip.
- `shared/ui/refinement-home.css`: made Recent filter/Open button and topbar suite controls consume canonical theme tokens explicitly.
- `shared/ui/app-home.css`: strengthened the shared AppHome host reset against legacy app-specific `!important` card styles.
- `shared/ui/app-home.css`: collapsed the Documents startup workspace to one column while AppHome is active and forced the viewport into that column, removing the blank/narrow startup composition.
- `tests/browser/revalidate_refinement_checkpoint.py`: now loads each page's actual linked styles, checks dark/light Home contrast, mobile gutter, mandatory Home widths, all six AppHomes across the width matrix plus landscape, and Documents full-width startup geometry.
- `tests/test_refinement_checkpoint.py`: added static contracts for the theme/gutter bridge and Documents grid escape.

## Local evidence

- Minimal Documents composition Chromium probe: AppHome visible; `.workspace` one 390 px column; `#viewport` 390 px; AppHome host 390 px at viewport 390x844.
- Minimal Home dark-theme Chromium probe: Recent content left/right gutter 20 px; body gradient resolves to the dark palette; `Open file` and suite controls resolve to `rgb(242, 244, 247)` text on `rgb(36, 41, 50)` surfaces.
- Python syntax compilation for the modified browser/unit regression files: PASS.
- Full repository validation: NOT TESTED locally because this environment does not contain a literal current checkout and blocks GitHub/local browser navigation.
- GitHub Actions beta.6/sequence 63 candidate gate: repository validation PASS, source audit PASS, architecture guardrails PASS, unit/package tests 380/380 PASS, browser regressions 26/27 PASS. The only failure was `revalidate_refinement_checkpoint.py` at the WCAG contrast assertion for Home `Open file`; transaction rolled back before commit/push.
- Follow-up contrast fix: Home `Open file` and topbar suite controls now receive explicit foreground/background pairs from `data-resolved-theme` (dark `#f2f4f7` on `#242932`; light `#202633` on `#fff`) with WebKit text fill pinned to the same foreground. The regression threshold remains 4.5:1 and now reports computed colors/ratio on failure.

