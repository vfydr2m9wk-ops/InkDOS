# InkDOS refinement acceptance matrix — checkpoint 2

Baseline: `1.0.0-beta.5`, sequence 62.
Checkpoint target: `1.0.0-beta.6`, sequence 63.

This checkpoint addresses the mobile Home gutter/theme regressions observed on-device and the Documents AppHome layout failure. PASS means direct evidence exists; PARCIAL means the remaining editor-wide phase still owns part of the criterion.

| # | Criterion | State | Evidence / scope |
|---:|---|---|---|
| 1 | Home has no visible giant app catalog | PASS | Active Home remains Recent-first. |
| 2 | Home is centered on Recent files | PASS | Recent remains the primary content. |
| 3 | Recent filters remain usable | PASS | Registry-derived All + six app filters; horizontal strip retained. |
| 4 | Clear Recent disappears when empty | PASS | Existing empty/populated/clear behavior retained. |
| 5 | Global Open/Create do not dominate Home | PASS | Only discreet empty-state Open remains. |
| 6 | Real grid app launcher exists | PASS | Registry-derived six-app launcher retained. |
| 7 | Launcher and Settings are separate | PASS | Separate shared surfaces retained. |
| 8 | Theme is global | PARCIAL | Home/suite/shared-shell token bridge is unified in this checkpoint; editor-wide token unification remains Phase 7. |
| 9 | No cramped native theme select in active UI | PASS | Shared Settings radio choices retained. |
| 10 | Launcher is available in apps | PASS | Shared trigger retained in all six apps. |
| 11 | Mobile AppHome is a normal page | PASS | Shared AppHome remains page-based. |
| 12 | Desktop AppHome uses available width | PASS | Shared AppHome retains wide desktop composition. |
| 13 | AppHome never exceeds viewport | PARCIAL | Documents-specific grid collision is fixed and a full-width regression was added; promotion awaits the full repository browser gate. |
| 14 | Editors never exceed viewport | NÃO TESTADO | Phase 6 editor matrix not yet completed. |
| 15 | Toolbars have dedicated mobile composition | NÃO TESTADO | Phase 6. |
| 16 | Long titles do not break toolbars | PARCIAL | Existing ellipsis behavior remains; full editor matrix is Phase 6. |
| 17 | File picker stays native/local | PASS | Existing native file inputs retained. |
| 18 | Apps limit file formats appropriately | PASS | Central registry contract retained. |
| 19 | Incompatible formats are handled without crash | PARCIAL | Phase 5 continuation. |
| 20 | Recent files route to correct module | PARCIAL | Phase 5 continuation. |
| 21 | Read-only apps do not invent creation | PASS | PDF/EPUB remain Open-only. |
| 22 | Bottom sheets respect safe area | PASS | Shared mobile sheets retain safe-area inset. |
| 23 | Dynamic viewport is used appropriately | PARCIAL | Shared surfaces use `dvh`; editor-wide verification remains Phase 6. |
| 24 | Institutional links do not occupy active mobile Home | PASS | Links remain in Settings. |
| 25 | No unnecessary duplicate navigation | PARCIAL | Shared roles are retained; final sanitization remains. |
| 26 | Desktop remains primary experience | PASS | No desktop editor composition is changed by this checkpoint. |
| 27 | Mobile is not merely compressed desktop | PARCIAL | Home/AppHome responsive treatment improved; editor toolbars remain Phase 6. |
| 28 | Dirty state is not discarded silently | PASS | Lifecycle/recovery behavior untouched. |
| 29 | Light/dark share structure | PARCIAL | Home now uses one canonical token bridge in both themes; editor-wide Phase 7 remains. |
| 30 | Application remains usable offline | PASS | No new runtime asset is introduced; existing precache continues to cover modified shared CSS. |

## Checkpoint 2 evidence before GitHub Actions

- On-device report identified mixed light/dark controls and insufficient horizontal gutter on the beta.5 Home.
- Source inspection confirmed `refinement-home.css` overrode the original bounded Home width and mixed canonical theme tokens with inherited `--muted`/`--edge`/suite tokens.
- Source inspection confirmed Documents AppHome remained inside the two-column editor workspace while the sidebar was hidden; legacy `.welcome-card` `!important` rules also overrode the shared AppHome host.
- Local Chromium composition probe after the fix measured the Documents AppHome host/viewport at 390 CSS px in a 390 px viewport, with a single workspace grid column and visible Create/Open/Recent content.
- Local Chromium dark-theme probe measured a 20 px mobile content gutter and explicit light text on dark `Open file` and suite controls.
- Full repository unit/browser/release validation is **NÃO TESTADO** for beta.6 until the package runs through GitHub Actions.
- Beta.6 gate evidence: 380/380 unit/package tests PASS and 26/27 Chromium regression scripts PASS. The sole blocker was the Home `Open file` contrast assertion; no commit/push occurred. The follow-up keeps criterion 29 PARCIAL while adding explicit resolved-theme contrast pairs without changing layout or the 4.5:1 acceptance threshold.

- Beta.6 follow-up gate (2026-09-05): the inline resolved-theme synchronizer still failed the immediate Home contrast assertion in Actions because MutationObserver delivery occurs after `applyTheme()` returns. The transaction rolled back and `main` remained unchanged.
- Beta.6 r2 keeps the 4.5:1 assertion unchanged and makes the normal `InkDOSAppShell.applyTheme()` path dispatch `inkdos:theme-changed` synchronously; `shared/suite-shell.js` consumes that event immediately while retaining the MutationObserver as a fallback for direct DOM attribute changes. Targeted Chromium verification measured 13.25:1 in dark and 15.15:1 in light. Full GitHub Actions validation remains pending.
