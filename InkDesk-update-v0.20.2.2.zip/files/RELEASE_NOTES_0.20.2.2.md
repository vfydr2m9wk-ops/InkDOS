# InkDesk v0.20.2.2 — Refactoring Guardrails

InkDesk v0.20.2.2 starts the architecture-hardening phase without adding or
removing editor functions. The purpose of this patch is to make future
refactoring safer for both AI-assisted and human development.

## Added

- `AGENTS.md` with smallest-scope, zero-regression, visual, local-first and
  update-package rules.
- `architecture-policy.json` recording the v0.20.2.1 source-debt baseline.
- `scripts/check_architecture_guardrails.py` as a permanent quality gate.
- Checks that new runtime JS/CSS stays focused and readable while existing debt
  may shrink but not grow.
- Runtime dependency checks for cross-workspace imports, shared-to-app imports
  and relative module cycles.
- An explicit native-module ADR: no React/framework migration during the 0.20.x
  behavior-neutral refactor.
- An ordered refactoring sequence: Presentations, PDF, shared UI, then
  Documents/Spreadsheets consolidation.

## Behavior

No editing command, supported format, file lifecycle, recovery behavior or
visual layout is intentionally changed by this release. Any runtime difference
is a regression and blocks the next extraction release.
