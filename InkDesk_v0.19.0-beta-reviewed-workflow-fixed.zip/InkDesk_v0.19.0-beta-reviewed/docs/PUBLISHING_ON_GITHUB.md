# Publishing on GitHub

## Repository source

Keep extracted source files directly on the `main` branch. Distribute the validated ZIP through GitHub Releases rather than committing generated archives to the source tree.

Visitors should be able to browse `apps/`, `shared/`, `tests/`, `scripts/`, and `docs/` directly. Do not commit `test-results/`, browser-generated exports, Python bytecode, or local temporary files.

## Repository metadata

**Description**

> Local-first browser editors for focused DOCX, XLS/XLSX, and PPTX workflows.

**Suggested topics**

`ooxml`, `local-first`, `offline`, `docx`, `xlsx`, `pptx`, `javascript`, `html-app`, `pwa`, `office-editor`

## GitHub Pages

The repository includes `.github/workflows/pages.yml`. In **Settings → Pages**, select **GitHub Actions** as the source.

Expected project URL:

`https://vfydr2m9wk-ops.github.io/inkdesk/`

GitHub Pages provides the HTTPS context required for service-worker registration. Verify the deployed manifest, service worker, workspace links, and offline reload in a real browser before describing the hosted build as installable.

## Automated release workflow

The repository includes `.github/workflows/publish-release.yml`. Run **Publish validated release ZIP** from the GitHub Actions tab to regenerate distributable checksums, execute three consecutive release-validation cycles, build the reviewed ZIP, verify the extracted archive, and create or update the GitHub Release for the version declared in `VERSION.json`. The workflow also uploads the ZIP and its SHA-256 file as a temporary Actions artifact.

## Release 0.19.0-beta

- Tag: `v0.19.0-beta`
- Target: `main`
- Title: `InkDesk 0.19.0-beta — Structural Cleanup and Integrity Review`
- Attach the validated application ZIP.
- Attach or link `docs/FINAL_REVIEW_REPORT.md` and `docs/VALIDATION_REPORT.md`.
- Publish the ZIP SHA-256.

Do not describe the project as production ready or fully compatible with Microsoft Office. State that compatibility is partial; native Firefox, Safari/WebKit, iPadOS, embedded hosts, and installed PWA behavior require separate validation.

## Mobile maintenance

This reviewed repository does not rely on a ZIP self-import workflow. When maintaining from a phone or tablet, prefer GitHub's file editor for small documentation changes or a trusted local Git client for source changes. Always let the quality gate validate the extracted repository structure; do not replace source with an opaque archive on `main`.

## Social preview

Upload `docs/images/social-preview.png` in the repository social-preview settings.
