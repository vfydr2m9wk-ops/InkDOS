# InkDesk 0.19.1-beta — Documentation Package

This archive contains the complete documentation set prepared for the focused InkDesk 0.19.1-beta hardening release.

## Baseline and implementation

- Inspected upstream commit: `538c99d7c09566644d2095aaf33305b890a4b4c7`
- Prepared branch: `hardening/0.19.1-beta`
- Final implementation commit: `cf96539b36c277f1ac4af54147da49f3ac5c4fef`
- Package date: 2026-08-04

## Folder guide

- `Root_Documents/`: README, security, compatibility, development, testing, release notes, version and release metadata.
- `Documentation/`: architecture, component, policy, roadmap, validation, manual-device and contributor documentation.
- `Implementation_Reports/`: implementation and release-test reports.
- `Validation_Evidence/`: executed browser results, summaries and logs, including unavailable-engine evidence.
- `Repository_Workflows/`: CI, browser-regression, Pages and prerelease workflow definitions.
- `Repository_Community/`: contribution templates and repository governance configuration.
- `Testing_Documentation/`: test-suite and fixture documentation.
- `Third_Party_Notices/`: bundled dependency license notices.
- `Release_Metadata/`: build metadata and SHA-256 records.

This archive intentionally excludes application source code, binaries, runtime packages, patches and Git bundles.
