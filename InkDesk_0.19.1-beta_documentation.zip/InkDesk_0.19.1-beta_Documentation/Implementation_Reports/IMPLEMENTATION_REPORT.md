# InkDesk 0.19.1-beta Hardening Implementation Report

## A. Baseline

- Upstream branch: `main`
- Upstream commit inspected: `538c99d7c09566644d2095aaf33305b890a4b4c7`
- Source archive SHA-256: `9152bc3051860c4067ecbfc30125b26199755cea07aa7126736e0a3549d842be`
- Version found: `0.19.0-beta`
- Local baseline commit used for the reviewable branch: `b9aa819cb35660d5139d66ab971bb8f7c37f2c8f`
- Final hardening commit: `cf96539b36c277f1ac4af54147da49f3ac5c4fef`
- Environment: Linux x86_64, Python 3.13.5, Node.js 22.16.0, npm 10.9.2, Playwright 1.57.0, system Chromium.
- GitHub write access and live Git network resolution were unavailable, so no remote branch or pull request was published.

Baseline executed evidence:

| Command | Result |
|---|---|
| `python3 scripts/verify_checksums.py` | Passed, 144 files |
| `python3 scripts/validate_repository.py` | Passed, 8 HTML and 5 JSON/manifest files |
| `python3 scripts/audit_source.py` | Passed; flagged dynamic construction in spreadsheet formula code |
| `python3 -m unittest discover -s tests -p "test_*.py"` | 43/43 passed |
| `python3 scripts/run_browser_regressions.py` | Did not complete as one aggregate command; first six scripts passed and the constrained system-Chromium environment stalled at cross-workspace isolation |

## B. Changes made

### Data integrity

- Added shared dirty/export lifecycle states for all three workspaces.
- A browser download request no longer clears dirty state or reports a definitive save.
- `beforeunload` remains active after unverified downloads.
- Exact exported-copy reopening is verified by SHA-256 plus byte length.
- Failed/blocked/repeated exports preserve warning state.
- Imported OOXML packages are patched conservatively and checked for unexpected part loss.

### Security

- Added deny-by-default DOCX DOM reconstruction.
- Removed active attributes, dangerous protocols, external resource loading, active SVG/embedded HTML, unsafe CSS URLs, and clobbering IDs/names from imported editable content.
- Added hostile browser tests that observed zero script execution and zero unexpected external requests.

### Formula evaluation

- Removed first-party `Function`/`eval` formula execution.
- Added a bounded recursive-descent arithmetic parser.
- Added limits for formula bytes, tokens, nesting, steps, cell references, recursion, and recalculation passes.
- Unsupported formulas retain cached values where available and are not silently reinterpreted.

### ZIP/XML validation

- Added raw ZIP inventory validation before JSZip.
- Enforced exact/casefold/Unicode collision rules, safe paths, local/central consistency, non-overlap, method restrictions, encryption/ZIP64 rejection, truncation detection, nested archive rejection, and mobile-oriented size/count/ratio limits.
- Added XML DTD/entity rejection and explicit part/aggregate/depth/node/attribute limits.
- Added OOXML relationship target validation.

### Architecture

- Added `shared/file-lifecycle.js`, `shared/formula-engine.js`, and `shared/safe-dom.js`.
- Expanded `shared/office-runtime.js` for package validation, XML budgets, fingerprints, inventory, filenames, URLs, and download feature detection.
- Kept the static HTML/CSS/JavaScript architecture; no backend, accounts, telemetry, cloud document processing, native wrapper, or large framework was introduced.
- Presentation responsibility splitting remains a documented follow-up rather than an unsafe rewrite in this release.

### Tests

- Expanded Python tests from 43 to 47.
- Added 46 direct JavaScript security assertions.
- Expanded Chromium browser coverage to 10 scripts, executed in five isolated groups.
- Added real open-edit-export-reopen verification for DOCX, XLS/XLSX, and PPTX.
- Added malicious ZIP/XML/DOM/formula and blocked-download failure scenarios.

### CI/release

- Added Playwright Chromium/Firefox/WebKit matrix workflows split into isolated scenario groups.
- Added deterministic tagged runtime packaging, SHA-256 output, exact commit metadata, artifact upload, and explicit opt-in prerelease publication.
- Removed the committed source ZIP and repository-bootstrap workflow.
- Kept workflow permissions read-only except the explicit publish job.

### Documentation

- Updated version, manifest, README, changelog, release notes, security, testing, compatibility, development, architecture, known limitations, release checklist, device checklist, upgrade notes, and validation evidence.
- Documentation distinguishes tested evidence from intended or untested support.

## C. Files changed

| Path(s) | Purpose | Risk |
|---|---|---|
| `shared/file-lifecycle.js` | Shared export/dirty/fingerprint state machine | High |
| `shared/formula-engine.js` | Deterministic bounded formula parser | High |
| `shared/safe-dom.js` | DOCX-derived DOM allowlist builder | High |
| `shared/office-runtime.js` | ZIP/XML/package/security validation and fingerprints | High |
| `apps/documents/app.js`, `docx-parser.js`, `docx-writer.js`, `index.html` | Lifecycle, safe DOM, validation, preservation export | High |
| `apps/spreadsheets/app.js`, `xlsx-engine.js`, `index.html` | Safe formulas, lifecycle, validation, preservation export | High |
| `apps/presentations/app.js`, `index.html` | Lifecycle, package inventory, fingerprint verification | High |
| `tests/js/security-modules.test.js`, `tests/test_security_modules.py` | Pure module/adversarial coverage | Medium |
| `tests/browser/*.py` | Round-trip, lifecycle, malicious input, isolation, offline checks | Medium |
| `tests/test_release_packaging.py`, `scripts/build_release.py` | Reproducible release package validation/build | Medium |
| `.github/workflows/browser-regression.yml`, `prerelease.yml`, `quality-gate.yml` | CI browser matrix, validation, prerelease artifacts | Medium |
| `.github/workflows/bootstrap-inkdesk.yml`, `InkDesk-source.zip` | Removed bootstrap/archive anti-pattern | Low |
| `README.md`, `SECURITY.md`, `COMPATIBILITY.md`, `TESTING.md`, `DEVELOPMENT.md` | Evidence-aligned public documentation | Low |
| `CHANGELOG.md`, `RELEASE_NOTES.md`, `RELEASE_TEST_REPORT.md`, `UPGRADE_NOTES.md` | Release communication and executed evidence | Low |
| `VERSION.json`, `RELEASE_MANIFEST.json`, `app-manifest.json`, `package.json`, `service-worker.js` | 0.19.1-beta metadata/cache/release configuration | Medium |
| `docs/*` changed files | Architecture, device checklist, limitations, release and historical clarifications | Low |
| `CHECKSUMS.sha256` | Final 158-file repository integrity manifest | Low |

## D. Final test evidence

| Exact command | Result | Count | Failures | Skipped/unavailable |
|---|---|---:|---:|---|
| `python3 scripts/verify_checksums.py` | Passed | 158 files | 0 | 0 |
| `python3 scripts/validate_repository.py` | Passed | 8 HTML; 5 JSON/manifest | 0 | 0 |
| `python3 scripts/audit_source.py` | Passed | Source audit | 0 | 0 |
| `node tests/js/security-modules.test.js` | Passed | 46 assertions | 0 | 0 |
| `python3 -m unittest discover -s tests -p "test_*.py"` | Passed | 47 tests | 0 | 0 |
| `PLAYWRIGHT_BROWSER=chromium python3 scripts/run_browser_regressions.py --group package-security` | Passed | 2 scripts | 0 | 0 |
| `PLAYWRIGHT_BROWSER=chromium python3 scripts/run_browser_regressions.py --group lifecycle` | Passed | 2 scripts | 0 | 0 |
| `PLAYWRIGHT_BROWSER=chromium python3 scripts/run_browser_regressions.py --group isolation-offline` | Passed | 2 scripts | 0 | 0 |
| `PLAYWRIGHT_BROWSER=chromium python3 scripts/run_browser_regressions.py --group documents-presentations` | Passed | 2 scripts | 0 | 0 |
| `PLAYWRIGHT_BROWSER=chromium python3 scripts/run_browser_regressions.py --group spreadsheets` | Passed | 2 scripts | 0 | 0 |
| `python3 -m unittest tests.test_release_packaging -v` | Passed | 1 test | 0 | 0 |
| JavaScript syntax loop using `node --check` over `apps` and `shared` | Passed | All first-party JS files | 0 | 0 |
| PyYAML parsing of `.github/workflows/*.yml` | Passed | 4 workflows | 0 | 0 |
| Firefox hardening launch | Not executable locally | — | — | Playwright Firefox executable missing |
| WebKit hardening launch | Not executable locally | — | — | Playwright WebKit executable missing |
| Native Safari, native Firefox packaging, physical iPadOS, installed PWA | Not tested | — | — | Environment/device unavailable |

## E. Remaining risks

- Browser downloads still cannot provide reliable OS-write confirmation; verification requires reopening the exact generated bytes.
- Native iPadOS/Safari behavior remains untested, including download UI, memory pressure, background/return, touch/pointer/keyboard, and PWA behavior.
- Playwright WebKit is configured in CI but is not equivalent to physical Safari/iPadOS.
- Advanced Office features can be preserved without being editable or rendered faithfully.
- Large packages are bounded but still processed synchronously; worker migration remains open.
- Presentation code remains a large coupled module.
- Crash/session recovery is not implemented.
- Exhaustive fuzzing, native Office validation, and arbitrary hostile-file safety are not proven.

## F. Release recommendation

**Ready for a controlled beta.**

The implemented P0 controls and executed Chromium/round-trip evidence justify another controlled beta. Native target-platform evidence and broader OOXML compatibility are insufficient for a public release candidate or 1.0.

## G. Patch and branch

- Branch: `hardening/0.19.1-beta`
- Commit: `cf96539b36c277f1ac4af54147da49f3ac5c4fef`
- Patch, Git bundle, source archive, runtime ZIP/checksum/build metadata, and test evidence are supplied beside this report.
