#!/usr/bin/env python3
"""Bootstrap a stable InkDOS package with the repository's trusted updater.

The workflow requires every update ZIP to carry ``files/scripts/apply_update_package.py``.
That member is a bootstrap only: it is removed from the candidate payload before the
checked-out repository updater applies the package. This prevents a package from
replacing the updater implementation that validates its own candidate while preserving
the workflow's explicit updater bootstrap contract.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

BOOTSTRAP_PAYLOAD = "files/scripts/apply_update_package.py"
BOOTSTRAP_REPO_PATH = "scripts/apply_update_package.py"
TRUSTED_UPDATER_GIT_BLOB = "a63af8f4ac260a33b1e5e95745749de9573cd548"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_trusted_updater(repo: Path):
    updater_path = (repo / BOOTSTRAP_REPO_PATH).resolve()
    if not updater_path.is_file():
        raise RuntimeError(f"Trusted repository updater is missing: {updater_path}")
    data = updater_path.read_bytes()
    blob_header = f"blob {len(data)}\0".encode("ascii")
    git_blob = hashlib.sha1(blob_header + data).hexdigest()
    if git_blob != TRUSTED_UPDATER_GIT_BLOB:
        raise RuntimeError(
            "Trusted repository updater does not match the required beta.4 base implementation."
        )
    workflow = repo / ".github/workflows/apply-inkdos-update.yml"
    if not workflow.is_file():
        raise RuntimeError("The stable InkDOS update workflow is missing from the base repository.")
    spec = importlib.util.spec_from_file_location("inkdos_trusted_updater", updater_path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Trusted repository updater could not be loaded.")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    for name in ("apply_package", "write_failure_report", "UpdateError"):
        if not hasattr(module, name):
            raise RuntimeError(f"Trusted repository updater is missing required API: {name}")
    return module


def sanitized_package(source: Path, destination: Path) -> None:
    """Copy the package without the bootstrap updater in its candidate payload."""
    with zipfile.ZipFile(source) as archive:
        manifest = json.loads(archive.read("patch-manifest.json").decode("utf-8"))
        files = manifest.get("files")
        if isinstance(files, dict):
            files.pop(BOOTSTRAP_REPO_PATH, None)
        names = [
            info.filename
            for info in archive.infolist()
            if not info.is_dir()
            and info.filename not in {"patch-manifest.json", BOOTSTRAP_PAYLOAD}
        ]
        with zipfile.ZipFile(destination, "w") as output:
            manifest_bytes = (
                json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
            ).encode("utf-8")
            info = zipfile.ZipInfo("patch-manifest.json", date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            output.writestr(info, manifest_bytes, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
            for name in sorted(names):
                data = archive.read(name)
                item = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
                item.compress_type = zipfile.ZIP_DEFLATED
                item.external_attr = 0o100644 << 16
                item.create_system = 3
                output.writestr(item, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", required=True, type=Path)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--validation-profile", choices=("none", "standard", "full"))
    parser.add_argument("--report", type=Path)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    package = args.package.resolve()
    repo = args.repo.resolve()
    updater = load_trusted_updater(repo)
    try:
        with tempfile.TemporaryDirectory(prefix="inkdos-bootstrap-") as temp_name:
            clean_package = Path(temp_name) / package.name
            sanitized_package(package, clean_package)
            plan = updater.apply_package(
                clean_package,
                repo,
                dry_run=args.dry_run,
                validation_override=args.validation_profile,
            )
            plan["packageSha256"] = sha256_file(package)
    except (updater.UpdateError, subprocess.CalledProcessError, OSError, RuntimeError, ValueError) as exc:
        if args.report:
            try:
                updater.write_failure_report(
                    args.report,
                    package,
                    repo,
                    exc,
                    dry_run=args.dry_run,
                )
            except Exception as report_error:
                print(f"WARNING: could not write failure report: {report_error}", file=sys.stderr)
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(plan, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    verb = "validated" if args.dry_run else "applied"
    print(f"OK: {verb} InkDOS update package {plan['packageLabel']}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
