#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path, PurePosixPath
TEXT_EXT={'.html','.js','.css','.json','.md','.py','.cff','.yml','.yaml','.webmanifest','.txt'}
PROTECTED_PREFIXES=('.git/','.github/workflows/')

def sha(path):
    h=hashlib.sha256();
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def safe_rel(value):
    p=PurePosixPath(str(value));
    if p.is_absolute() or any(part in {'','.', '..'} for part in p.parts) or '\\' in str(value):raise ValueError(f'Unsafe repository path: {value}')
    return p.as_posix()
def protected(rel):return rel=='.git' or rel.startswith(PROTECTED_PREFIXES)
def copy_repo(src,dst,package):
    def ignore(directory,names):
        rel=Path(directory).resolve().relative_to(src.resolve()).as_posix() if Path(directory).resolve()!=src.resolve() else ''
        skipped=[]
        for name in names:
            path=(rel+'/'+name).lstrip('/')
            if name=='.git' or path.startswith('.github/workflows/') or (not rel and name==package.name):skipped.append(name)
        return skipped
    shutil.copytree(src,dst,ignore=ignore)
def load_json(path):return json.loads(path.read_text(encoding='utf-8'))
def run(repo,args):
    print('+',' '.join(args),flush=True);subprocess.run(args,cwd=repo,check=True)
def apply_files(candidate,archive,manifest):
    copied=[]
    for rel,contract in sorted((manifest.get('files') or {}).items()):
        rel=safe_rel(rel)
        if protected(rel):raise ValueError(f'Protected path in package: {rel}')
        member='files/'+rel
        data=archive.read(member)
        expected=contract.get('sha256')
        if expected and hashlib.sha256(data).hexdigest()!=expected:raise ValueError(f'Payload hash mismatch: {rel}')
        target=candidate/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);copied.append(rel)
    return copied
def apply_replacements(candidate,manifest):
    report=[]
    for rel,replacements in sorted((manifest.get('textReplacements') or {}).items()):
        rel=safe_rel(rel);target=candidate/rel
        text=target.read_text(encoding='utf-8')
        for item in replacements:
            old,new=item['old'],item['new'];count=text.count(old);expected=item.get('count')
            if expected is not None and count!=expected:raise ValueError(f'{rel}: expected {expected} matches, found {count}')
            if count<1:raise ValueError(f'{rel}: replacement source not found')
            text=text.replace(old,new);report.append({'path':rel,'matches':count})
        target.write_text(text,encoding='utf-8',newline='\n')
    for item in (manifest.get('operations') or {}).get('treeReplacements',[]):
        old,new=item['old'],item['new'];extensions=set(item.get('extensions') or []);excluded=set(item.get('excludePaths') or []);prefixes=tuple(item.get('excludePrefixes') or []);matches=0
        for path in sorted(candidate.rglob('*')):
            if not path.is_file():continue
            rel=path.relative_to(candidate).as_posix()
            if rel in excluded or rel.startswith(prefixes) or protected(rel):continue
            if extensions and path.suffix not in extensions:continue
            try:text=path.read_text(encoding='utf-8')
            except UnicodeDecodeError:continue
            count=text.count(old)
            if count:text=text.replace(old,new);path.write_text(text,encoding='utf-8',newline='\n');matches+=count
        if matches<item.get('minMatches',0):raise ValueError(f'Tree replacement {old!r}: only {matches} matches')
        if item.get('maxMatches') is not None and matches>item['maxMatches']:raise ValueError(f'Tree replacement {old!r}: {matches} exceeds max')
        report.append({'tree':old,'matches':matches})
    return report
def apply_deletions(candidate,manifest):
    deleted=[]
    for rel in sorted((manifest.get('deletions') or {}).keys()):
        rel=safe_rel(rel)
        if protected(rel):raise ValueError(f'Protected deletion: {rel}')
        target=candidate/rel
        if target.is_dir():shutil.rmtree(target);deleted.append(rel)
        elif target.exists():target.unlink();deleted.append(rel)
    return deleted
def generated_state(candidate,manifest):
    (candidate/'DEVELOPMENT_STATE.json').write_text(json.dumps({'schemaVersion':2,'appliedSequence':manifest['sequence'],'currentPackage':manifest['packageLabel'],'status':'complete'},indent=2)+'\n',encoding='utf-8')
    for command in (['python','scripts/generate_module_registry.py'],['python','scripts/generate_release_metadata.py'],['python','scripts/generate_checksums.py']):
        if (candidate/command[1]).is_file():run(candidate,command)
def validate(candidate,profile):
    if profile=='none':return
    if profile=='full':
        run(candidate,['python','scripts/check_no_legacy_runtime.py']);run(candidate,['python','scripts/run_release_validation.py']);return
    for command in (['python','scripts/validate_repository.py'],['python','scripts/audit_source.py'],['python','scripts/check_architecture_guardrails.py'],['python','-m','unittest','discover','-s','tests','-p','test_*.py'],['python','scripts/verify_checksums.py']):run(candidate,command)
def sync(candidate,repo,package):
    existing=[]
    for path in repo.rglob('*'):
        if not path.is_file():continue
        rel=path.relative_to(repo).as_posix()
        if protected(rel) or path==package:continue
        existing.append(rel)
    desired={p.relative_to(candidate).as_posix() for p in candidate.rglob('*') if p.is_file()}
    for rel in existing:
        if rel not in desired:(repo/rel).unlink(missing_ok=True)
    for path in sorted(candidate.rglob('*')):
        if not path.is_file():continue
        rel=path.relative_to(candidate).as_posix();target=repo/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--package',required=True,type=Path);parser.add_argument('--repo',required=True,type=Path);parser.add_argument('--report',type=Path);parser.add_argument('--dry-run',action='store_true');parser.add_argument('--validation-profile',choices=['none','standard','full']);args=parser.parse_args()
    package=args.package.resolve();repo=args.repo.resolve();report={'status':'failed'}
    try:
        with zipfile.ZipFile(package) as archive:
            manifest=json.loads(archive.read('patch-manifest.json').decode('utf-8'))
            if manifest.get('schemaVersion')!=2 or manifest.get('product')!='InkDOS':raise ValueError('Unsupported InkDOS package manifest.')
            state=load_json(repo/'DEVELOPMENT_STATE.json');version=load_json(repo/'VERSION.json')['version'];requires=manifest.get('requires') or {}
            if requires.get('previousSequence') is not None and state.get('appliedSequence')!=requires['previousSequence']:raise ValueError(f"Sequence mismatch: repository={state.get('appliedSequence')} package requires={requires['previousSequence']}")
            if requires.get('appVersions') and version not in requires['appVersions']:raise ValueError(f'App version {version} is not accepted by this package.')
            profile=args.validation_profile or manifest.get('validationProfile','standard')
            with tempfile.TemporaryDirectory(prefix='inkdos-update-') as temp:
                candidate=Path(temp)/'candidate';copy_repo(repo,candidate,package);copied=apply_files(candidate,archive,manifest);replacements=apply_replacements(candidate,manifest);deleted=apply_deletions(candidate,manifest);generated_state(candidate,manifest);validate(candidate,profile)
                report={'status':'validated','packageLabel':manifest['packageLabel'],'targetRelease':manifest.get('targetRelease'),'sequence':manifest['sequence'],'validationProfile':profile,'copied':copied,'deleted':deleted,'replacements':replacements}
                if not args.dry_run:sync(candidate,repo,package);report['status']='applied'
        if args.report:args.report.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        print(json.dumps(report,indent=2,ensure_ascii=False));return 0
    except Exception as exc:
        report['error']=str(exc)
        if args.report:args.report.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        print(f'ERROR: {exc}',file=sys.stderr);return 1
if __name__=='__main__':raise SystemExit(main())
