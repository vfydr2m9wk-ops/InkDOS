# InkDesk 0.19.0-beta — Foundation

This release establishes InkDesk as the new identity of the local-first browser productivity suite. It is primarily a repository, documentation, and metadata migration; no intentional user-facing workflow redesign is included.

The release retains focused DOCX, XLS/BIFF8, XLSX, and PPTX editing, local processing, package-preserving exports where supported, and the existing automated validation baseline. Native Firefox, Safari/WebKit, iPadOS, embedded-host, and installed-PWA validation are not claimed for this release.
