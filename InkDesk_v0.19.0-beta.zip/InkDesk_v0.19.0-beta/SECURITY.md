# Security Policy

InkDesk treats imported Office documents as untrusted input. It does not intentionally execute VBA macros, ActiveX, embedded JavaScript, add-ins, or remote document instructions. Core processing is local and the project includes no telemetry or document-upload backend.

Report vulnerabilities privately through GitHub Security Advisories when available. Include the affected version, browser/platform, reproduction steps, and a minimal proof of concept. Do not publish sensitive details before a fix can be evaluated.

Current hardening priorities include parser resource limits, malformed-package tests, ZIP expansion limits, XML safety review, and broader browser validation.
