# Changelog

## [0.19.0-beta] - 2026-08-03

### Changed
- Established the InkDesk identity and repository metadata.
- Consolidated documentation around the actual static-client architecture and current validation evidence.
- Renamed public launch and release assets for the new project.

### Preserved
- Existing DOCX, XLS/BIFF8, XLSX, and PPTX workflows.
- Local-first and offline-capable architecture.
- 39-test baseline and Chromium browser regression scripts.

### Fixed
- Removed obsolete release automation and duplicated historical documentation from the clean repository baseline.
