# Compatibility

InkDesk provides partial, focused compatibility rather than complete Microsoft Office fidelity.

| Format | Status | Notes |
|---|---|---|
| DOCX | Partially supported | Common text, formatting, images, tables, lists, sections, headers, and footers |
| XLSX | Partially supported | Common cells, styles, worksheets, formulas, images, and package-preserving export |
| XLS (BIFF8) | Import only | Imported locally and saved as a new XLSX copy |
| PPTX | Partially supported | Common slides, text, images, layouts, masters, notes resolution, charts preview, and presentation mode |
| DOC / PPT binary | Unsupported | Rejected with a controlled message |
| PDF | Out of scope | Use a dedicated PDF viewer/editor |

## Browser status

- Chromium/Playwright: automated regression performed.
- Edge: historically exercised manually, but not part of the current automated report.
- Firefox: not validated for this release.
- Safari/WebKit and iPadOS: not validated for this release.
- Embedded browsers and installed PWA mode: not validated for this release.

Local `file://` behavior depends on host security policies. Static HTTP hosting is the most predictable mode.
