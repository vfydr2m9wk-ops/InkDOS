#!/usr/bin/env python3
"""Fail on common prototype-to-repository risks."""
from __future__ import annotations

import re
import sys
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
CODE_SUFFIXES = {".js", ".html", ".css", ".py"}
VENDOR_PARTS = {"vendor"}
PROTOTYPE_MARKER = re.compile(
    r"\b(" + "TO" + "DO|FI" + "XME|HA" + "CK|ST" + "UB)\b|" + "not " + "implemented|coming " + "soon",
    re.I,
)
ABSOLUTE_HOST = re.compile("file:///var/mobile/" + "Containers|/var/mobile/" + "Containers")


class RuntimeReferenceParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.remote_runtime_refs: list[str] = []

    def handle_starttag(self, tag, attrs):
        data = dict(attrs)
        ref = data.get("src") if tag == "script" else data.get("href") if tag == "link" and data.get("rel") == "stylesheet" else None
        if ref and urlparse(ref).scheme in {"http", "https"}:
            self.remote_runtime_refs.append(ref)


def main() -> int:
    errors: list[str] = []
    metrics: list[tuple[int, Path]] = []

    for path in ROOT.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in CODE_SUFFIXES:
            continue
        if any(part in VENDOR_PARTS for part in path.parts):
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        rel = path.relative_to(ROOT)
        lines = text.count("\n") + 1
        metrics.append((lines, rel))
        if lines > 1000:
            errors.append(f"Source file exceeds 1000 lines and needs an explicit refactoring plan: {rel} ({lines})")
        if PROTOTYPE_MARKER.search(text):
            errors.append(f"Prototype marker found in runtime/source file: {rel}")
        if ABSOLUTE_HOST.search(text):
            errors.append(f"Device-specific absolute path found: {rel}")
        if path.suffix.lower() == ".html":
            parser = RuntimeReferenceParser()
            parser.feed(text)
            for ref in parser.remote_runtime_refs:
                errors.append(f"Automatic remote runtime dependency: {rel} -> {ref}")

    print("Largest non-vendor source files:")
    for lines, rel in sorted(metrics, reverse=True)[:10]:
        print(f"- {lines:4d} lines  {rel}")

    if errors:
        print("\nSource audit failed:")
        for error in errors:
            print(f"- {error}")
        return 1

    print("\nSource audit passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
