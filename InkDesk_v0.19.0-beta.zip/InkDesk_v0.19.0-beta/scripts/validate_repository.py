#!/usr/bin/env python3
"""Static repository checks for InkDesk."""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED_DIRS = {".git"}
NEUTRAL_BRAND_PATTERN = re.compile("xe" + "os", re.IGNORECASE)
ABSOLUTE_HOST_PATTERN = re.compile("file:///var/mobile/" + "Containers|/var/mobile/" + "Containers")


class HTMLInspector(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.ids: list[str] = []
        self.refs: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = dict(attrs)
        if values.get("id"):
            self.ids.append(values["id"] or "")
        for key in ("src", "href"):
            value = values.get(key)
            if value:
                self.refs.append(value)


def iter_files(pattern: str):
    for path in ROOT.rglob(pattern):
        if any(part in EXCLUDED_DIRS for part in path.parts):
            continue
        yield path


def is_external(ref: str) -> bool:
    parsed = urlparse(ref)
    return bool(parsed.scheme in {"http", "https", "mailto", "tel", "data", "javascript"} or ref.startswith("#"))


def main() -> int:
    errors: list[str] = []

    json_docs: dict[Path, object] = {}
    for path in iter_files("*.json"):
        try:
            json_docs[path] = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            errors.append(f"Invalid JSON: {path.relative_to(ROOT)}: {exc}")

    for path in iter_files("*.html"):
        parser = HTMLInspector()
        try:
            parser.feed(path.read_text(encoding="utf-8"))
        except Exception as exc:
            errors.append(f"Invalid HTML parse: {path.relative_to(ROOT)}: {exc}")
            continue

        duplicates = sorted({item for item in parser.ids if parser.ids.count(item) > 1})
        if duplicates:
            errors.append(f"Duplicate HTML IDs in {path.relative_to(ROOT)}: {', '.join(duplicates)}")

        for ref in parser.refs:
            clean = ref.split("#", 1)[0].split("?", 1)[0]
            if not clean or is_external(ref) or clean.startswith("/"):
                continue
            target = (path.parent / clean).resolve()
            try:
                target.relative_to(ROOT.resolve())
            except ValueError:
                errors.append(f"Reference escapes repository: {path.relative_to(ROOT)} -> {ref}")
                continue
            if not target.exists():
                errors.append(f"Missing local reference: {path.relative_to(ROOT)} -> {ref}")

    text_extensions = {".html", ".css", ".js", ".md", ".json", ".yml", ".yaml", ".txt", ".py"}
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in text_extensions:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        if NEUTRAL_BRAND_PATTERN.search(text):
            errors.append(f"Legacy product reference found: {path.relative_to(ROOT)}")
        if ABSOLUTE_HOST_PATTERN.search(text):
            errors.append(f"Device-specific path found: {path.relative_to(ROOT)}")

    case_map: dict[str, list[Path]] = {}
    for path in ROOT.rglob("*"):
        if path.is_file():
            key = str(path.relative_to(ROOT)).casefold()
            case_map.setdefault(key, []).append(path.relative_to(ROOT))
    for matches in case_map.values():
        if len(matches) > 1:
            errors.append("Case-insensitive filename conflict: " + ", ".join(map(str, matches)))

    node = shutil.which("node")
    if node:
        for path in iter_files("*.js"):
            if "vendor" in path.parts:
                continue
            result = subprocess.run([node, "--check", str(path)], capture_output=True, text=True)
            if result.returncode:
                detail = (result.stderr or result.stdout).strip().splitlines()[-1]
                errors.append(f"Invalid JavaScript syntax: {path.relative_to(ROOT)}: {detail}")
    else:
        print("Warning: Node.js is unavailable; JavaScript syntax checks were not performed.")

    required = [
        ROOT / "index.html",
        ROOT / "LICENSE",
        ROOT / "README.md",
        ROOT / "app-manifest.json",
        ROOT / "VERSION.json",
        ROOT / "apps/documents/index.html",
        ROOT / "apps/spreadsheets/index.html",
        ROOT / "apps/presentations/index.html",
        ROOT / "tests/fixtures/minimal.docx",
        ROOT / "tests/fixtures/minimal.xlsx",
        ROOT / "tests/fixtures/minimal.pptx",
    ]
    for path in required:
        if not path.exists():
            errors.append(f"Required file missing: {path.relative_to(ROOT)}")

    manifest = json_docs.get(ROOT / "app-manifest.json")
    version = json_docs.get(ROOT / "VERSION.json")
    package = json_docs.get(ROOT / "package.json")
    release_manifest = json_docs.get(ROOT / "RELEASE_MANIFEST.json")
    if isinstance(manifest, dict) and isinstance(version, dict):
        expected_version = version.get("version")
        if manifest.get("version") != expected_version:
            errors.append("Version mismatch between app-manifest.json and VERSION.json")
        if not isinstance(package, dict) or package.get("version") != expected_version:
            errors.append("Version mismatch between package.json and VERSION.json")
        if not isinstance(release_manifest, dict) or release_manifest.get("version") != expected_version:
            errors.append("Version mismatch between RELEASE_MANIFEST.json and VERSION.json")
        for launcher in manifest.get("launchers", []):
            target = ROOT / launcher.get("entryPoint", "")
            if not target.is_file():
                errors.append(f"Manifest launcher is missing: {launcher.get('entryPoint')}")

    if errors:
        print("Repository validation failed:\n")
        for error in errors:
            print(f"- {error}")
        return 1

    html_count = sum(1 for _ in iter_files("*.html"))
    json_count = sum(1 for _ in iter_files("*.json"))
    print(f"Repository validation passed ({html_count} HTML files, {json_count} JSON files).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
