# Development Guide

InkDesk intentionally avoids a mandatory build system. Source files are served directly.

## Setup

```bash
python3 -m http.server 8080
```

## Principles

Keep changes small, preserve offline operation, avoid unnecessary dependencies, maintain workspace isolation, and update tests and documentation together with behavior changes. All source code, comments, identifiers, filenames, and developer-facing messages must remain in English.

## Commands

```bash
python3 scripts/validate_repository.py
python3 scripts/audit_source.py
python3 -m unittest discover -s tests -p "test_*.py"
```

Use focused commits such as `fix:`, `docs:`, `test:`, `refactor:`, and `chore:`. Do not rename persisted storage keys without migration or backward-compatible fallback.
