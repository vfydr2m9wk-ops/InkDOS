# Testing Guide

Every meaningful change requires static validation, targeted tests, and broader regression. Data corruption, silent save failure, stale export, and cross-workspace contamination are critical defects.

## Automated baseline

- Repository and metadata validation.
- Source audit for remote dependencies and risky constructs.
- 39 Python unit and preservation tests.
- JavaScript syntax validation with Node.js when available.
- Chromium/Playwright round-trip scripts for DOCX, XLSX, BIFF8 XLS, and PPTX.

## Release loop

Run the relevant suite after each meaningful batch and repeat the complete logical suite three consecutive times before a release candidate. Record unavailable browsers as `Not Tested`; never infer compatibility.
