# Publishing on GitHub

## Repository source

Keep extracted source files directly on the `main` branch. ZIP files belong in GitHub Releases, except for the temporary mobile-import package described below. The import workflow removes that ZIP after a successful update.

Visitors should be able to browse `apps/`, `shared/`, `tests/`, `scripts/` and `docs/` directly.

## Repository metadata

**Description**

> Experimental local-first HTML editors for focused DOCX, XLSX and PPTX workflows.

**Suggested topics**

`ooxml`, `local-first`, `offline`, `docx`, `xlsx`, `pptx`, `javascript`, `html-app`, `webview`, `office-editor`

## Mobile update workflow

The repository includes `.github/workflows/mobile-bootstrap.yml` for maintainers working from a phone or tablet.

1. Upload exactly one GitHub-import ZIP to the repository root.
2. Open **Actions → Mobile package import → Run workflow**.
3. Enter the exact ZIP filename.
4. The workflow safely extracts the package, accepts either root-level files or a single outer folder, validates the extracted project, replaces the repository contents, removes the temporary ZIP and commits using the version from `VERSION.json`.
5. The resulting push triggers the independent quality gate and GitHub Pages deployment workflows.

The import workflow deliberately preserves `.github/workflows/` because the automatic GitHub token must not rewrite workflow definitions during its own run. Update workflow files manually before importing a package that changes automation.

## GitHub Pages

The repository includes `.github/workflows/pages.yml`. In **Settings → Pages**, use **GitHub Actions** as the source.

Expected URL:

`https://vfydr2m9wk-ops.github.io/inkdesk/`

## Release 0.18.5

- Tag: `v0.18.5`
- Target: `main`
- Title: `InkDesk 0.18.5 — Integrated OOXML Compatibility`
- Attach the validated application ZIP.
- Attach the full three-era validation evidence ZIP.
- Optionally attach the validation contact sheet.
- Use `.github/RELEASE_BODY_0.18.5.md` as the release description.

Do not describe the project as production ready or fully compatible with Microsoft Office. State that DOC, XLS and PPT require conversion, WebKit device validation remains pending and unsupported OOXML features are preserved when possible but may not be editable.

## Social preview

Upload `docs/images/social-preview.png` in the repository social-preview settings.
