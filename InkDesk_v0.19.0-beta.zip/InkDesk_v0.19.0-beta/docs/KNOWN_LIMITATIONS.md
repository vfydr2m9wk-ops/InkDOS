# Known Limitations

## General

- The suite does not aim for Microsoft Office feature parity.
- Saving creates a new copy rather than overwriting the source.
- Browser and host policies control file access, downloads and fullscreen.
- Unsupported OOXML content may be skipped; silent data loss is treated as a bug.
- Fonts can be substituted and change layout.

## Documents

- Imported DOCX packages preserve unsupported OOXML parts, but fields, comments, equations, embedded Office objects and complex drawing layouts are not fully editable.
- Text inside content controls and tracked insertions is visible; editing it can alter review semantics even though the original wrapper markup is retained.
- New blank documents still use a compact generated DOCX rather than a full Microsoft Word template.
- Pagination is approximate and not pixel-identical.
- Legacy `.doc` remains outside the offline scope.

## Spreadsheets

- BIFF8 `.xls` files can be imported and converted to `.xlsx`; older BIFF variants and password-protected files may be rejected.
- BIFF8 shared strings spanning CONTINUE records are supported by the regression corpus, but unusual rich-text/phonetic continuation layouts remain best effort.
- Legacy formula expressions are not reconstructed from BIFF tokens; their cached displayed results are imported as values.
- VBA, ActiveX, old Excel charts and unsupported embedded OLE objects are not converted from `.xls`.
- Imported packages preserve unsupported parts, but only edited cells, row heights, column widths and merge definitions are intentionally patched. Structural row/column operations can leave advanced range-based objects requiring repair in a full spreadsheet suite.
- Formula preview coverage remains focused. `XLOOKUP`, `FILTER` and `LET` support common exact-match and simple-range cases, not the full Excel calculation language.
- Dynamic arrays are shown as a preview inside the formula cell rather than materialized as editable spill cells.
- Basic column/bar charts are rendered from cached values or direct worksheet references. Advanced charts, secondary axes, trendlines and interactive editing remain unsupported.
- Conditional formatting, validation, filters, tables, pivot structures and print settings are preserved in imported files but are not fully interactive in the local editor.
- Macros and VBA remain unsupported.

## Presentations

- Legacy `.ppt` remains outside the offline scope and must be converted to `.pptx`.
- Imported files preserve unedited OOXML parts, but SmartArt, WordArt, OLE, advanced SVG effects, embedded audio/video and animations are not locally editable.
- Cached bar and column chart data can be previewed. Advanced chart families, external workbook refresh, secondary axes and chart editing remain unsupported.
- Layout/master inheritance is best-effort across file producers and missing source fonts can change line wrapping.
- Presenter notes are preserved and editable when the imported PPTX already has a notes part. Notes added to a newly generated presentation are not exported yet.
- Insert, delete or duplicate slide operations are blocked during imported-package preservation export. This is an explicit safety boundary, not silent data loss.
- New blank presentations use a compact generated PPTX rather than a full Microsoft PowerPoint template.
- Fullscreen can be blocked by an embedded WebView.
