# Architecture

InkDesk is a static client-side application with three independent workspaces. `index.html` is the hub; each workspace has its own HTML, CSS, state, parser/writer logic, and entry point under `apps/`.

## Runtime model

Files are selected through browser file inputs, parsed in memory, edited locally, and exported as new downloads. The original file is not directly overwritten. Modern browser APIs are optional enhancements, not the sole save path.

## Responsibilities

- `apps/documents/`: DOCX parser, editor, and writer.
- `apps/spreadsheets/`: BIFF8/XLS importer and XLSX parser/writer.
- `apps/presentations/`: PPTX editor, renderer, and presentation mode.
- `shared/`: common visual shell only.
- `scripts/`: repository validation, source audit, fixtures, and checksums.
- `tests/`: unit, package-preservation, and browser regression tests.

## Isolation

Each workspace owns its filename, dirty state, editing model, history, selection, imported assets, and temporary resources. A workspace must not mutate another workspace's state.

## Import and export

OOXML formats are ZIP packages. Supported parts are converted to an internal editing model; unsupported package parts are preserved where possible. BIFF8 XLS is imported locally and exported as a new XLSX copy; InkDesk does not generate binary XLS files.

## Error and security boundaries

Imported files are untrusted. InkDesk does not intentionally execute macros, embedded scripts, ActiveX, or remote document instructions. Parsing and saving failures must preserve dirty state and must not report success falsely.
