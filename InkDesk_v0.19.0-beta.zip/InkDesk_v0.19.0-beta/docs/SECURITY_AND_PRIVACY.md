# Security and Privacy

- Document parsing and editing occur in the browser process.
- The suite does not require an account or application server for its core editors.
- Selected files are handled in memory according to the permissions of the browser or host container.
- Saving creates a browser-generated local copy.
- No telemetry or analytics code is included in this package.
- Untrusted OOXML documents should be treated as untrusted ZIP/XML input. The developer should retain size limits and avoid executing embedded scripts or macros. This prototype does not execute Office macros.
