# Project Status

InkDesk is an **experimental stabilization preview**.

## Suitable current uses

- OOXML compatibility experiments;
- local and embedded editor prototypes;
- non-critical workflows where exported copies are manually verified;
- community work on parsers, rendering and regression fixtures.

## Not suitable without independent validation

- regulated, medical, legal or financial production workflows;
- unattended conversion;
- documents requiring exact Microsoft Office formatting;
- files that depend on macros, SmartArt, advanced charts, embedded applications or proprietary fonts.

## Current engineering priority

1. reproducible tests;
2. clear failure behavior;
3. create/open/export reliability;
4. source cleanup and refactoring;
5. demand validation;
6. only then, selective new compatibility features.
