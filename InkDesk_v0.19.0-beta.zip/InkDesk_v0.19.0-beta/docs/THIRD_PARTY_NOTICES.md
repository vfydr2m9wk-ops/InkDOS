# Third-Party Notices

## JSZip

The repository includes JSZip for ZIP/OOXML package handling. JSZip is distributed under the MIT License and/or GPLv3 as described by the upstream project.

## pako

The repository includes pako inflate support. Pako is distributed under the MIT License.

## Fonts

No proprietary Microsoft fonts are bundled. Font family names may appear as document metadata, but availability and substitution are controlled by the user's platform.

Third-party files remain subject to their upstream licenses. Contributors must not add dependencies or assets without documenting their source and redistribution terms.
