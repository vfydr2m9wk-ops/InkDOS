<p align="center">
  <img src="docs/images/readme-banner.png" alt="InkDesk — local-first browser productivity suite" width="100%">
</p>

# InkDesk

> **The lightweight local-first productivity suite.**

InkDesk is an open-source, browser-native suite for focused DOCX, XLS/XLSX, and PPTX workflows. It runs from static HTML, CSS, and JavaScript, processes files in the current browser context, and does not require a project-operated backend.

**Project status: Beta (`0.19.0-beta`).** Compatibility with advanced Microsoft Office features is partial and no claim of complete fidelity is made.

## Workspaces

| Workspace | Formats | Current focus |
|---|---|---|
| Documents | DOCX | Basic editing, formatting, images, tables, lists, headers/footers, and package-preserving copy export |
| Spreadsheets | XLS import; XLSX open/save | BIFF8 import, values, cached formulas, styles, images, worksheet editing, and XLSX copy export |
| Presentations | PPTX | Basic slide editing, images, layouts, presentation mode, and package-preserving copy export |

## Privacy and offline operation

Core processing is local. InkDesk has no accounts, telemetry, analytics, mandatory cloud synchronization, or remote document-processing API. Bundled runtime dependencies are stored in the repository.

## Quick start

Serve the repository with any static server:

```bash
python3 -m http.server 8080
```

Open `http://localhost:8080/`. Compatible local-file hosts may open `index.html` directly. Saving creates a new downloadable copy and does not silently overwrite the selected source file.

## Validation

```bash
python3 scripts/verify_checksums.py
python3 scripts/validate_repository.py
python3 scripts/audit_source.py
python3 -m unittest discover -s tests -p "test_*.py"
```

The current reviewed baseline contains 39 unit tests and Chromium/Playwright round-trip scripts for DOCX, XLSX, BIFF8 XLS, and PPTX. Native Firefox, Safari/WebKit, iPadOS, installed PWA, and embedded-host validation remain separate device tests.

## Documentation

- [Architecture](docs/ARCHITECTURE.md)
- [Compatibility](docs/COMPATIBILITY.md)
- [Development](docs/DEVELOPMENT.md)
- [Testing](docs/TESTING.md)
- [Validation report](docs/VALIDATION_REPORT.md)
- [Security](SECURITY.md)
- [Roadmap](docs/ROADMAP.md)
- [Contributing](CONTRIBUTING.md)

## License

Original InkDesk code is licensed under the MIT License. Bundled third-party components retain their upstream licenses and notices.
