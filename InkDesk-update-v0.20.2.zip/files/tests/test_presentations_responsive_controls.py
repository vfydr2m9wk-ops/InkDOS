from __future__ import annotations

import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class PresentationsResponsiveControlsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.css = (ROOT / "apps/presentations/styles.css").read_text(encoding="utf-8")
        cls.app = (ROOT / "apps/presentations/app.js").read_text(encoding="utf-8")
        cls.html = (ROOT / "apps/presentations/index.html").read_text(encoding="utf-8")
        cls.recovery_test = (ROOT / "tests/browser/revalidate_v0202_local_recovery.py").read_text(encoding="utf-8")
        cls.shell_css = (ROOT / "shared/office-shell.css").read_text(encoding="utf-8")

    def test_compact_layout_overrides_legacy_hidden_inspector(self):
        marker = "/* 0.20.2 responsive format-panel drawer */"
        self.assertIn(marker, self.css)
        tail = self.css.split(marker, 1)[1]
        self.assertIn("display:block!important", tail)
        self.assertIn(".workspace.inspector-open .inspector", tail)
        self.assertIn("visibility:visible!important", tail)


    def test_legacy_compact_display_none_rule_is_removed(self):
        self.assertNotIn(".inspector{display:none}", self.css)

    def test_shared_shell_finishes_the_presentations_drawer_cascade(self):
        marker = "/* 0.20.2 presentations format-panel cascade guard"
        self.assertIn(marker, self.shell_css)
        tail = self.shell_css.split(marker, 1)[1]
        self.assertIn("@media (min-width:1001px)", tail)
        self.assertIn("position:relative!important", tail)
        self.assertIn("@media (max-width:1000px)", tail)
        self.assertIn("position:fixed!important", tail)
        self.assertIn(".workspace.inspector-open .inspector", tail)
        self.assertIn("visibility:visible!important", tail)

    def test_shell_is_loaded_after_product_styles_and_owns_final_cascade(self):
        product_pos = self.html.index('href="styles.css"')
        shell_pos = self.html.index('href="../../shared/office-shell.css"')
        self.assertLess(product_pos, shell_pos)
        self.assertIn("presentations format-panel cascade guard", self.shell_css)

    def test_compact_toggle_has_explicit_mode(self):
        self.assertIn("matchMedia('(max-width:1000px)')", self.app)
        self.assertIn("presentationWorkspace.classList.toggle('inspector-open')", self.app)
        self.assertIn("presentationWorkspace.classList.toggle('hide-inspector')", self.app)

    def test_format_toggle_exposes_accessibility_state(self):
        self.assertIn('aria-controls="inspector"', self.html)
        self.assertIn("button.setAttribute('aria-expanded',String(open))", self.app)

    def test_escape_closes_compact_format_panel(self):
        self.assertIn("event.key==='Escape'", self.app)
        self.assertIn("presentationWorkspace.classList.remove('inspector-open')", self.app)

    def test_recovery_test_does_not_depend_on_notes_visibility(self):
        self.assertIn("node.value=value", self.recovery_test)
        self.assertNotIn('page.fill("#presenterNotes", token)', self.recovery_test)

    def test_behavioral_control_regression_is_registered(self):
        runner = (ROOT / "scripts/run_browser_regressions.py").read_text(encoding="utf-8")
        self.assertIn('"revalidate_presentations_controls.py"', runner)


if __name__ == "__main__":
    unittest.main()
