# InkDesk 0.20.2 — Data Safety and Browser Matrix

InkDesk 0.20.2 is a focused data-safety release. It does not add editing tools.

## Local recovery

Documents, Spreadsheets and Presentations now keep bounded recovery snapshots in IndexedDB after unsaved edits. On a later launch, the user can restore the latest private snapshot, open normally without deleting it, or discard it. The original selected file is never overwritten.

Retention is intentionally limited to three snapshots per document, twelve per workspace and thirty days. A confirmed copy download clears the active document recovery data.

## Browser validation

The standard incremental-update validation remains Chromium-only so workflow duration stays predictable. The repository also includes an explicit matrix runner for installed Playwright Chromium, Firefox and WebKit binaries. Strict mode can require every requested engine.

The incremental updater no longer repeats unit, audit and repository gates before calling the complete release validator. Full package validation now uses one release-validation pass.

Versioned application-shell URLs such as `module-registry.js?v=0.20.2` are canonicalized to their pre-cached shell entries before offline fallback, making the hosted offline check deterministic instead of depending on the browser HTTP cache.

## Scope

- No new editing features.
- No workflow-file changes in the update package.
- PDF, TXT and EPUB behavior is unchanged.
