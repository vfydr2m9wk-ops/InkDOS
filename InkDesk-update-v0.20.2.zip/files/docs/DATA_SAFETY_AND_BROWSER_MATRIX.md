# Data Safety and Browser Matrix

## Private recovery snapshots

InkDesk 0.20.2 stores unsaved recovery snapshots only in the browser IndexedDB database `InkDeskLocalRecovery`. Documents, Spreadsheets and Presentations use separate workspace namespaces. The source file is retained only as local browser data when it is needed to reconstruct a package-preserving copy. No recovery data is sent to an InkDesk server.

Recovery never overwrites the selected source file. On startup, the user chooses **Restore**, **Open normally**, or **Discard recovery**. A successful copy-download request clears the active document's snapshots and retained source.

Retention is bounded to three snapshots per document, twelve per workspace and thirty days.

## Browser validation

The stable incremental update workflow runs the complete Chromium regression suite once. The updater does not repeat unit, audit or repository gates before the complete release validator, keeping hosted-runner duration predictable.

The hosted offline regression also verifies cache-busted shell URLs against canonical pre-cache keys, so `?v=` release tokens do not bypass the service-worker application shell.

Run the explicit installed-browser matrix with:

```bash
python3 scripts/run_browser_matrix.py
```

The runner checks Chromium, Firefox and WebKit. Missing engines are reported and skipped by default. To require every requested engine:

```bash
INKDESK_BROWSER_MATRIX_STRICT=1 python3 scripts/run_browser_matrix.py
```

Select engines with `INKDESK_BROWSERS=chromium,firefox,webkit`.
