# Release integrity

InkDesk 0.20.1 treats consistency as a release contract.

## Authoritative source

`VERSION.json` is the only manually edited product release identity.
Run:

```text
python3 scripts/sync_release_identity.py
```

to synchronize dependent files, or use `--check` in CI.

The synchronizer covers public package metadata, six module manifests and
launchers, the web manifest, module configuration and generated registry,
service-worker cache identity, visible release labels, citation metadata, SBOM,
and publication references.

Internal subsystem versions are not automatically rewritten. They may identify
stable parser, renderer, schema or compatibility contracts and are distinct
from the public InkDesk release.

## Workflows

- `apply-inkdesk-update.yml`: transactional incremental ZIP updates.
- `ci.yml`: permanent push and pull-request regression gate.
- `publish-inkdesk-release.yml`: generic complete-release publication driven by
  `VERSION.json`.

No release workflow may hard-code a product version.
