# Consistency and regression policy

Starting with InkDesk 0.20.1, the project is in refinement and stabilization.

A patch is blocked when it removes an existing function, changes an equivalent control inconsistently between workspaces, leaves public versions and cache identifiers out of sync, or fails any inherited or feature-specific regression test.

Every corrected regression receives a permanent test. New work must preserve Home navigation, local file open/new/save flows, unsaved-change warnings, spreadsheet range selection, formula-reference selection, PDF review/save, TXT editing, EPUB reading, and the established visual system.


## Product identity versus subsystem versions

The product release is sourced only from `VERSION.json`. Public package,
launcher, cache, citation, SBOM and release metadata must match it. Internal
parser, renderer, schema and compatibility contracts may retain independent
versions when they describe a stable subsystem rather than the public release.

## Permanent gates

Every push and pull request checks generated identity, module registry, static
validation, source audit, checksums, the full unit suite and Chromium interaction
regressions. Firefox and WebKit automation remain scheduled for the 0.20.2
browser-matrix milestone; until then their manual results must be recorded.
