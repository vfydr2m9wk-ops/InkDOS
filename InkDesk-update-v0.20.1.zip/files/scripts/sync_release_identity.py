#!/usr/bin/env python3
"""Synchronize public InkDesk release identity from VERSION.json.

VERSION.json is the only manually edited product release identity. Internal
subsystem/schema versions may remain independent when they describe a stable
compatibility contract rather than the public product release.
"""
from __future__ import annotations

import argparse
import copy
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SEMVER = re.compile(r"^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$")
CACHE_RE = re.compile(r"const CACHE_NAME=['\"]inkdesk-shell-v[^'\"]+['\"];")
MODULE_ORDER = ('documents','spreadsheets','presentations','pdf','txt','epub')


def read_json(relative: str) -> dict:
    path = ROOT / relative
    value = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(value, dict):
        raise SystemExit(f'{relative} must contain a JSON object')
    return value


def render_json(value: dict) -> str:
    return json.dumps(value, indent=2, ensure_ascii=False) + '\n'


def next_patch(version: str) -> str:
    core = version.split('-', 1)[0]
    major, minor, patch = (int(part) for part in core.split('.'))
    return f'{major}.{minor}.{patch + 1}'


def update_text(text: str, version: str, channel: str) -> str:
    text = re.sub(r'InkDesk v\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?', f'InkDesk v{version}', text)
    text = re.sub(r'v\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)? beta', f'v{version} {channel}', text)
    return text


def expected_files() -> dict[str, str]:
    version_doc = read_json('VERSION.json')
    version = str(version_doc.get('version', ''))
    if not SEMVER.fullmatch(version):
        raise SystemExit(f'Invalid VERSION.json version: {version!r}')
    channel = str(version_doc.get('releaseChannel') or 'beta')
    date = str(version_doc.get('date') or '')
    components = version_doc.get('components')
    if not isinstance(components, dict) or tuple(components) != MODULE_ORDER:
        raise SystemExit('VERSION.json components must contain the six modules in canonical order')

    module_docs: dict[str, dict] = {}
    for module_id in MODULE_ORDER:
        module_path = ROOT / f'apps/{module_id}/module.json'
        module = json.loads(module_path.read_text(encoding='utf-8'))
        if module.get('id') != module_id:
            raise SystemExit(f'Module ID mismatch: {module_path}')
        expected_entry = components[module_id].get('path')
        if module.get('entryPoint') != expected_entry:
            raise SystemExit(f'VERSION.json path and module entry point disagree for {module_id}')
        module['version'] = version
        module_docs[module_id] = module

    rendered: dict[str, str] = {}
    for module_id, module in module_docs.items():
        rendered[f'apps/{module_id}/module.json'] = render_json(module)

    package = read_json('package.json')
    package['version'] = version
    rendered['package.json'] = render_json(package)

    build = read_json('BUILD_INFO.json')
    build.update({
        'product': 'InkDesk',
        'version': version,
        'buildDate': date,
        'channel': channel,
        'modules': list(MODULE_ORDER),
        'requiresPreviousPackages': False,
    })
    rendered['BUILD_INFO.json'] = render_json(build)

    source = read_json('SOURCE_MANIFEST.json')
    source.update({
        'product': 'InkDesk',
        'version': version,
        'generatedAt': date,
        'entryPoint': 'index.html',
        'publicationWorkflow': '.github/workflows/publish-inkdesk-release.yml',
    })
    rendered['SOURCE_MANIFEST.json'] = render_json(source)

    release = read_json('RELEASE_MANIFEST.json')
    release.update({
        'project': 'InkDesk',
        'version': version,
        'releaseName': version_doc.get('releaseName', ''),
        'releaseDate': date,
    })
    rendered['RELEASE_MANIFEST.json'] = render_json(release)

    app = read_json('app-manifest.json')
    app['version'] = version
    app.setdefault('update', {})['nextPatch'] = next_patch(version)
    app['launchers'] = [
        {'id':'suite','name':'InkDesk','entryPoint':'index.html','icon':'assets/icons/office.png'}
    ] + [
        {
            'id': module_id,
            'name': module_docs[module_id]['name'],
            'entryPoint': module_docs[module_id]['entryPoint'],
            'icon': module_docs[module_id]['icon'],
        }
        for module_id in MODULE_ORDER
    ]
    app.setdefault('releaseIntegritySystem', {}).update({
        'version': version,
        'authority': 'VERSION.json',
        'synchronizer': 'scripts/sync_release_identity.py',
        'moduleIds': list(MODULE_ORDER),
        'ciWorkflow': '.github/workflows/ci.yml',
        'publicationWorkflow': '.github/workflows/publish-inkdesk-release.yml',
    })
    rendered['app-manifest.json'] = render_json(app)

    web = read_json('manifest.webmanifest')
    web['name'] = f'InkDesk {version}'
    web['description'] = 'Local-first DOCX, XLS/XLSX, PPTX, PDF, TXT and EPUB workspaces.'
    web['shortcuts'] = [
        {
            'name': module_docs[module_id]['name'],
            'short_name': {'documents':'Documents','spreadsheets':'Spreadsheets','presentations':'Presentations','pdf':'PDF','txt':'TXT','epub':'EPUB'}[module_id],
            'url': module_docs[module_id]['entryPoint'],
            'icons': [{'src': module_docs[module_id]['icon'], 'sizes':'512x512', 'type':'image/png'}],
        }
        for module_id in MODULE_ORDER
    ]
    rendered['manifest.webmanifest'] = render_json(web)

    config = read_json('modules/module-config.json')
    config['registryVersion'] = version
    rendered['modules/module-config.json'] = render_json(config)

    worker_path = ROOT / 'service-worker.js'
    worker = worker_path.read_text(encoding='utf-8')
    if not CACHE_RE.search(worker):
        raise SystemExit('service-worker.js does not expose a canonical CACHE_NAME')
    worker = CACHE_RE.sub(f"const CACHE_NAME='inkdesk-shell-v{version}';", worker, count=1)
    rendered['service-worker.js'] = worker

    public_pages = {
        'index.html': None,
        'apps/documents/index.html': 'Documents',
        'apps/spreadsheets/index.html': 'Spreadsheets',
        'apps/presentations/index.html': 'Presentations',
        'apps/pdf/index.html': 'PDF Workspace',
        'apps/txt/index.html': None,
        'apps/epub/index.html': None,
    }
    for relative, label in public_pages.items():
        text = (ROOT / relative).read_text(encoding='utf-8')
        text = update_text(text, version, channel)
        # Product asset revisions use major version zero. Pinned third-party
        # revisions such as JSZip 3.10.1 and PDF.js 3.11.174 remain unchanged.
        text = re.sub(
            r'([?&]v=)0\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?',
            rf'\g<1>{version}',
            text,
        )
        if label:
            text = re.sub(
                rf'<title>{re.escape(label)} — InkDesk [^<]+</title>',
                f'<title>{label} — InkDesk {version}</title>',
                text,
            )
        text = re.sub(
            r'\b0\.\d+\.\d+(?:-[0-9A-Za-z.-]+)? beta ·',
            f'{version} {channel} ·',
            text,
        )
        rendered[relative] = text


    citation = (ROOT / 'CITATION.cff').read_text(encoding='utf-8')
    citation = re.sub(r'(?m)^version:\s*.*$', f'version: {version}', citation)
    citation = re.sub(
        r'(?m)^abstract:\s*.*$',
        'abstract: InkDesk is an open-source, browser-native, local-first productivity suite for focused DOCX, XLS/XLSX, PPTX, PDF, TXT and EPUB workflows.',
        citation,
    )
    rendered['CITATION.cff'] = citation

    sbom = read_json('SBOM.spdx.json')
    sbom['name'] = f'InkDesk-v{version}'
    sbom['documentNamespace'] = f'https://github.com/vfydr2m9wk-ops/InkDesk/releases/tag/v{version}'
    for package_entry in sbom.get('packages', []):
        if package_entry.get('SPDXID') == 'SPDXRef-Package-InkDesk':
            package_entry['versionInfo'] = version
    rendered['SBOM.spdx.json'] = render_json(sbom)

    vendor = read_json('VENDOR_SOURCES.json')
    for item in vendor.get('vendors', []):
        if item.get('publicationStep'):
            item['publicationStep'] = '.github/workflows/publish-inkdesk-release.yml'
    rendered['VENDOR_SOURCES.json'] = render_json(vendor)

    return rendered


def synchronize(check: bool) -> int:
    rendered = expected_files()
    stale: list[str] = []
    for relative, expected in rendered.items():
        path = ROOT / relative
        current = path.read_text(encoding='utf-8') if path.is_file() else ''
        if current == expected:
            continue
        if check:
            stale.append(relative)
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(expected, encoding='utf-8', newline='\n')
    if check:
        if stale:
            print('Release identity is out of sync:', file=sys.stderr)
            for relative in stale:
                print(f'- {relative}', file=sys.stderr)
            return 1
        result = subprocess.run([sys.executable, 'scripts/generate_module_registry.py', '--check'], cwd=ROOT)
        if result.returncode:
            return result.returncode
        print('OK: release identity is synchronized from VERSION.json.')
        return 0
    result = subprocess.run([sys.executable, 'scripts/generate_module_registry.py'], cwd=ROOT)
    if result.returncode:
        return result.returncode
    print('OK: release identity synchronized from VERSION.json.')
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    return synchronize(args.check)


if __name__ == '__main__':
    raise SystemExit(main())
