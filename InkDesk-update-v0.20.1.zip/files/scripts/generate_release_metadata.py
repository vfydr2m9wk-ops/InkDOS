#!/usr/bin/env python3
"""Backward-compatible entry point for release identity synchronization."""
from __future__ import annotations

from sync_release_identity import synchronize


if __name__ == '__main__':
    raise SystemExit(synchronize(False))
