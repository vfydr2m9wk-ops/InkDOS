# InkDesk 0.20.1 — Consistency Refinement 1

This patch begins the refinement and stabilization phase after 0.20.0.

## Corrected regressions

- Documents once again exposes Home as the first title-bar action.
- Presentations exposes Home both before opening a file and in the editor title bar.
- Spreadsheet click-and-drag once again selects a continuous cell range.
- Formula reference selection only captures grid pointer events while a formula cursor is in a reference-accepting position.

## Release gate

Loss of an existing function, inconsistent equivalent controls, stale version/cache state, or a failed regression test blocks the patch. The package includes unit and Chromium checks dedicated to Home navigation and spreadsheet selection.


## Release integrity

- `VERSION.json` is now the authoritative public release identity.
- `scripts/sync_release_identity.py` writes or checks dependent metadata.
- A permanent CI workflow runs on pushes and pull requests.
- The publication workflow reads the release dynamically instead of hard-coding 0.20.0.
- The six-module inventory, launchers, cache identity, SBOM and citation metadata are checked together.
