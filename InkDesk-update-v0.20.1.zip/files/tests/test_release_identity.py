from __future__ import annotations

from pathlib import Path
import json
import re
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
MODULES = ('documents','spreadsheets','presentations','pdf','txt','epub')


class ReleaseIdentityTests(unittest.TestCase):
    def test_authoritative_synchronizer_reports_clean_tree(self):
        result = subprocess.run(
            [sys.executable, 'scripts/sync_release_identity.py', '--check'],
            cwd=ROOT,
            capture_output=True,
            text=True,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_public_identity_and_six_modules_match(self):
        version = json.loads((ROOT/'VERSION.json').read_text(encoding='utf-8'))
        release = version['version']
        self.assertEqual(tuple(version['components']), MODULES)
        for relative in ('package.json','BUILD_INFO.json','app-manifest.json','SOURCE_MANIFEST.json','RELEASE_MANIFEST.json'):
            self.assertEqual(json.loads((ROOT/relative).read_text(encoding='utf-8'))['version'], release, relative)
        config = json.loads((ROOT/'modules/module-config.json').read_text(encoding='utf-8'))
        self.assertEqual(config['registryVersion'], release)
        for module in MODULES:
            self.assertEqual(json.loads((ROOT/f'apps/{module}/module.json').read_text(encoding='utf-8'))['version'], release)
        self.assertIn(f"inkdesk-shell-v{release}", (ROOT/'service-worker.js').read_text(encoding='utf-8'))

    def test_publication_is_dynamic_and_ci_is_permanent(self):
        workflows = ROOT/'.github/workflows'
        self.assertFalse((workflows/'publish-inkdesk-v0.20.0.yml').exists())
        publish = (workflows/'publish-inkdesk-release.yml').read_text(encoding='utf-8')
        ci = (workflows/'ci.yml').read_text(encoding='utf-8')
        self.assertIn("json.loads(Path('VERSION.json')", publish)
        self.assertIn('Release InkDesk v${VERSION}', publish)
        self.assertIn('push:', ci)
        self.assertIn('pull_request:', ci)
        self.assertIn('scripts/sync_release_identity.py --check', ci)
        self.assertIn('scripts/run_browser_regressions.py', ci)

    def test_compatibility_and_html_asset_identity_are_current(self):
        release = json.loads((ROOT/'VERSION.json').read_text(encoding='utf-8'))['version']
        compatibility = (ROOT/'COMPATIBILITY.md').read_text(encoding='utf-8')
        self.assertIn('| PDF | Local review workspace |', compatibility)
        self.assertIn('| TXT | Supported for focused editing |', compatibility)
        self.assertIn('| EPUB | Supported for focused reading |', compatibility)
        self.assertNotIn('| PDF | Out of scope |', compatibility)
        for relative in (
            'index.html',
            'apps/documents/index.html',
            'apps/spreadsheets/index.html',
            'apps/presentations/index.html',
            'apps/pdf/index.html',
            'apps/txt/index.html',
            'apps/epub/index.html',
        ):
            html = (ROOT/relative).read_text(encoding='utf-8')
            stale = re.findall(r'[?&]v=(0\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?)', html)
            self.assertTrue(all(item == release for item in stale), (relative, stale))

    def test_citation_sbom_and_vendor_reference_current_release(self):
        release = json.loads((ROOT/'VERSION.json').read_text(encoding='utf-8'))['version']
        citation = (ROOT/'CITATION.cff').read_text(encoding='utf-8')
        sbom = json.loads((ROOT/'SBOM.spdx.json').read_text(encoding='utf-8'))
        vendor = json.loads((ROOT/'VENDOR_SOURCES.json').read_text(encoding='utf-8'))
        self.assertIn(f'version: {release}', citation)
        self.assertEqual(sbom['name'], f'InkDesk-v{release}')
        self.assertEqual(sbom['packages'][0]['versionInfo'], release)
        self.assertEqual(vendor['vendors'][0]['publicationStep'], '.github/workflows/publish-inkdesk-release.yml')


if __name__ == '__main__':
    unittest.main()
