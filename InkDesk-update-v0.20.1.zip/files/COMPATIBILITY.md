# Compatibility

InkDesk provides focused, partial compatibility rather than complete Microsoft Office fidelity. The project is local-first: files are processed in the browser, and Save normally produces a new local copy.

| Format | Status | Notes |
|---|---|---|
| DOCX | Partially supported | Common text, formatting, images, tables, lists, sections, headers, footers, and package-preserving export |
| XLSX | Partially supported | Common cells, styles, worksheets, formulas, images, chart previews, and package-preserving export |
| XLS (BIFF8) | Import only | Imported locally and exported as a new XLSX copy |
| PPTX | Partially supported | Common slides, text, images, layouts, masters, notes resolution, chart previews, transitions, and presentation mode |
| PDF | Local review workspace | PDF.js rendering, selectable text, forms, navigation, zoom, bookmarks, annotations, local review state, and copy export; no structural page editing |
| TXT | Supported for focused editing | Local plain-text editing with encoding-aware opening and copy export |
| EPUB | Supported for focused reading | Local reflowable reading, themes, font sizing, navigation, and images; no DRM bypass |
| DOC / PPT binary | Unsupported | Rejected with a controlled message |

## Browser and host status

| Environment | Review status |
|---|---|
| Chromium through Playwright | Automated structural and interaction regressions |
| Chromium touch/tablet viewport | Automated focused fallback and interaction checks |
| Static HTTP(S) asset delivery | Covered by local hosted test runs |
| Direct `file://` navigation | Host-policy dependent; limitations must remain documented |
| Hosted PWA installation and offline reload | Requires browser-controlled validation |
| Native Firefox | Planned for the v0.20.2 browser matrix |
| Native Safari/WebKit | Planned for the v0.20.2 browser matrix |
| Native iPhone/iPadOS WebKit | Mandatory manual release validation |
| Edge on Windows | Mandatory manual release validation |

A passing Chromium run does not establish Firefox, Safari, iPadOS, or installed-PWA compatibility.
