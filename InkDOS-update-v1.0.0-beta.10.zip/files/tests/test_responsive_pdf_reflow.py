from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class ResponsivePdfReflowTests(unittest.TestCase):
    def test_pdf_responsive_styles_are_loaded(self):
        html = (ROOT / "apps/pdf/index.html").read_text(encoding="utf-8")
        self.assertIn("responsive-reflow.css", html)

    def test_pdf_responsive_css_reflows_chrome(self):
        css = (ROOT / "apps/pdf/responsive-reflow.css").read_text(encoding="utf-8")
        self.assertIn("flex-wrap:wrap!important", css)
        self.assertIn("grid-template-columns:minmax(0,1fr)!important", css)
        self.assertIn("grid-template-rows:44px auto minmax(0,1fr) 44px!important", css)
        self.assertIn(".pdf-page-shell", css)
        self.assertIn("@media (max-width:420px)", css)

    def test_pdf_renderer_uses_live_container_padding(self):
        renderer = (ROOT / "apps/pdf/viewer/page-renderer.js").read_text(encoding="utf-8")
        self.assertIn("getComputedStyle(E.pdfPages)", renderer)
        self.assertIn("horizontalPadding", renderer)
        self.assertIn("Math.max(96", renderer)

    def test_pdf_viewer_observes_resizes_in_fit_modes(self):
        app = (ROOT / "apps/pdf/app.js").read_text(encoding="utf-8")
        self.assertIn("new ResizeObserver", app)
        self.assertIn("state.zoom === 'page-width'", app)
        self.assertIn("state.zoom === 'page-fit'", app)
        self.assertIn("pdfResponsiveObserver?.observe(E.viewerStage)", app)
        self.assertIn("state.zoom = 'page-width'", app)

if __name__ == "__main__":
    unittest.main()
