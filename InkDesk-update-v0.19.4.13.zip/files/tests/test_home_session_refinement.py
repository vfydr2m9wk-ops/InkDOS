from __future__ import annotations

from pathlib import Path
import json
import unittest

ROOT = Path(__file__).resolve().parents[1]


class HomeSessionRefinementTests(unittest.TestCase):
    def test_home_order_and_quiet_copy(self):
        html = (ROOT / "index.html").read_text(encoding="utf-8")
        cards = html.index('class="app-grid"')
        universal_open = html.index('class="open-any-panel"')
        principles = html.index('class="quick-panel"')
        stabilization = html.index(
            'class="status-callout status-callout-compact"'
        )
        footer = html.index('class="hub-footer"')
        self.assertLess(cards, universal_open)
        self.assertLess(universal_open, principles)
        self.assertLess(principles, stabilization)
        self.assertLess(stabilization, footer)
        self.assertNotIn(
            "Choose a DOCX, XLS, XLSX, PPTX or PDF file.",
            html,
        )
        self.assertIn(
            "The selected file stays on this device.",
            html,
        )
        self.assertIn(
            "InkDesk 0.19.3-beta.7 · build 0.19.4.13",
            html,
        )
        self.assertNotIn('class="version"', html)

    def test_start_action_contrast_and_spreadsheet_layout(self):
        visual = (
            ROOT / "shared/ui/visual-foundation.css"
        ).read_text(encoding="utf-8")
        self.assertIn(
            ".office-documents .welcome-actions .new-primary",
            visual,
        )
        self.assertIn("background:#fff!important", visual)
        self.assertIn(
            ".office-documents .welcome-actions "
            ".open-document-primary",
            visual,
        )
        self.assertIn(
            "grid-template-columns:repeat(2,minmax(0,1fr))",
            visual,
        )

        self.assertIn(
            "body.office-presentations .titlebar .doc-title.file-title-input",
            visual,
        )

        self.assertIn(
            "body.office-pdf #docTitle.file-title-input",
            visual,
        )

    def test_all_current_workspace_titles_are_inputs(self):
        expectations = {
            "apps/documents/index.html": "titleText",
            "apps/spreadsheets/index.html": "docTitle",
            "apps/presentations/index.html": "docTitle",
            "apps/pdf/index.html": "docTitle",
        }
        for relative, identifier in expectations.items():
            html = (ROOT / relative).read_text(encoding="utf-8")
            self.assertRegex(
                html,
                rf'<input[^>]+id="{identifier}"',
                relative,
            )

    def test_renames_update_export_names(self):
        sheets = (
            ROOT / "apps/spreadsheets/app.js"
        ).read_text(encoding="utf-8")
        presentations = (
            ROOT / "apps/presentations/app.js"
        ).read_text(encoding="utf-8")
        pdf = (
            ROOT / "apps/pdf/app.js"
        ).read_text(encoding="utf-8")
        documents = (
            ROOT / "apps/documents/app.js"
        ).read_text(encoding="utf-8")
        self.assertIn("book.fileName=next", sheets)
        self.assertIn("pres.name=next", presentations)
        self.assertIn("fileName: state.fileName", pdf)
        self.assertIn("setDirty(true)", documents)

    def test_shared_lifecycle_auto_installs_guard(self):
        lifecycle = (
            ROOT / "shared/file-lifecycle.js"
        ).read_text(encoding="utf-8")
        for marker in (
            "const activeControllers=new Set()",
            "function anyWorkspaceNeedsWarning()",
            "installUnloadGuard()",
            "global.addEventListener('beforeunload'",
            "confirmDiscard(",
            "version:'0.19.4.13'",
        ):
            self.assertIn(marker, lifecycle)

    def test_pdf_uses_shared_lifecycle(self):
        html = (ROOT / "apps/pdf/index.html").read_text(
            encoding="utf-8"
        )
        script = (ROOT / "apps/pdf/app.js").read_text(
            encoding="utf-8"
        )
        self.assertLess(
            html.index("file-lifecycle.js?v=0.19.4.13"),
            html.index("app.js?v=0.19.4.13"),
        )
        for marker in (
            "window.InkDeskFileLifecycle.create",
            "lifecycle.markDirty()",
            "lifecycle.resetClean()",
            "lifecycle.confirmDiscard(",
        ):
            self.assertIn(marker, script)

    def test_manifest_records_contract(self):
        manifest = json.loads(
            (ROOT / "app-manifest.json").read_text(
                encoding="utf-8"
            )
        )
        self.assertEqual(
            manifest["homeRefinement"]["version"],
            "0.19.4.13",
        )
        self.assertTrue(
            manifest["documentSessionSystem"][
                "automaticBeforeUnloadGuard"
            ]
        )

    def test_cache_advances_without_changing_public_version(self):
        worker = (ROOT / "service-worker.js").read_text(
            encoding="utf-8"
        )
        package = json.loads(
            (ROOT / "package.json").read_text(
                encoding="utf-8"
            )
        )
        self.assertIn("modules-0.19.4.13", worker)
        self.assertEqual(package["version"], "0.19.3-beta.7")


if __name__ == "__main__":
    unittest.main()
