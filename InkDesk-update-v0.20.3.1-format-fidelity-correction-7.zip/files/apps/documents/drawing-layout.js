(function(global){
'use strict';
const EMU_PER_CSS_PIXEL=9525;
function descendants(root,name){
  if(!root)return [];
  return Array.from(root.getElementsByTagName('*')).filter(node=>node.localName===name);
}
function first(root,name){return descendants(root,name)[0]||null}
function positiveNumber(value){const n=Number(value);return Number.isFinite(n)&&n>0?n:0}
function imageStyle(drawing){
  const extent=first(drawing,'extent')||first(drawing,'ext');
  const cx=positiveNumber(extent&&extent.getAttribute('cx'));
  const cy=positiveNumber(extent&&extent.getAttribute('cy'));
  if(!cx||!cy)return '';
  const width=Math.round((cx/EMU_PER_CSS_PIXEL)*1000)/1000;
  const height=Math.round((cy/EMU_PER_CSS_PIXEL)*1000)/1000;
  return 'width:'+width+'px;height:'+height+'px;max-width:100%;aspect-ratio:'+cx+' / '+cy+';object-fit:contain;';
}
global.InkDeskDocumentDrawingLayout={imageStyle};
})(window);
