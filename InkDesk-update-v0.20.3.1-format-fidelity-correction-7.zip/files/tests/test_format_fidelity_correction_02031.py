from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class FormatFidelityCorrection02031Tests(unittest.TestCase):
    def test_documents_loads_drawing_layout_before_parser(self):
        html = (ROOT / 'apps/documents/index.html').read_text(encoding='utf-8')
        self.assertIn('drawing-layout.js?v=0.20.3.1', html)
        self.assertLess(html.index('drawing-layout.js?v=0.20.3.1'), html.index('docx-parser.js?v=0.20.3.0'))

    def test_docx_parser_preserves_ooxml_drawing_extent_and_safe_font_css(self):
        parser = (ROOT / 'apps/documents/docx-parser.js').read_text(encoding='utf-8')
        helper = (ROOT / 'apps/documents/drawing-layout.js').read_text(encoding='utf-8')
        self.assertIn('InkDeskDocumentDrawingLayout.imageStyle(drawing)', parser)
        self.assertIn('EMU_PER_CSS_PIXEL=9525', helper)
        self.assertIn("font-family:'", parser)
        self.assertNotIn("font-family:'+JSON.stringify(props.fontFamily)", parser)

    def test_presentations_loads_background_resolver_before_app(self):
        html = (ROOT / 'apps/presentations/index.html').read_text(encoding='utf-8')
        self.assertIn('engine/background-resolver.js?v=0.20.3.1', html)
        self.assertLess(html.index('engine/background-resolver.js?v=0.20.3.1'), html.index('app.js?v=0.20.3.0'))

    def test_presentations_resolves_direct_background_images_without_expanding_main_app(self):
        app = (ROOT / 'apps/presentations/app.js').read_text(encoding='utf-8')
        helper = (ROOT / 'apps/presentations/engine/background-resolver.js').read_text(encoding='utf-8')
        self.assertIn('InkDeskPresentationsBackground.resolve', app)
        self.assertIn("first(bg,'blipFill')", helper)
        self.assertIn("size:'100% 100%'", helper)
        self.assertLessEqual(len(app.splitlines()), 698)

    def test_new_runtime_modules_are_offline_cached(self):
        worker = (ROOT / 'service-worker.js').read_text(encoding='utf-8')
        self.assertIn('./apps/documents/drawing-layout.js', worker)
        self.assertIn('./apps/presentations/engine/background-resolver.js', worker)


if __name__ == '__main__':
    unittest.main()
